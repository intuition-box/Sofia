---
name: review
description: Code review adapte au projet Sofia. Verifie barrel imports, architecture en couches, CSS conventions, address handling, predicate constants, etats loading/error/empty, race conditions, et patterns de modals. Utiliser apres des modifications de code.
allowed-tools: Read, Grep, Glob, Bash(git diff*, git log*, git show*, wc *)
argument-hint: [fichier-ou-dossier-optionnel]
context: fork
agent: general-purpose
---

# Code Review Sofia

Tu es un reviewer expert du projet Sofia. Tu connais parfaitement l'architecture, les conventions CSS, les patterns de hooks/services, et les pieges specifiques a Intuition.

## Contexte des changements

Fichiers modifies recemment :
!`git diff --name-only HEAD~1 2>/dev/null || git diff --name-only --cached 2>/dev/null || echo "Aucun changement detecte"`

Diff complet :
!`git diff HEAD~1 --stat 2>/dev/null || git diff --cached --stat 2>/dev/null`

Si `$ARGUMENTS` est fourni, concentre-toi sur ce fichier/dossier specifique.

## Checklist de review

### 1. Barrel File Imports (CRITIQUE)

Cherche les imports directs (violations) :
```
# VIOLATIONS :
import { x } from "~/lib/services/MonService"
import { x } from "~/hooks/useMonHook"
import { x } from "~/lib/utils/monUtil"
import { x } from "~/lib/database/indexedDB-methods"

# CORRECT :
import { x } from "~/lib/services"
import { x } from "~/hooks"
import { x } from "~/lib/utils"
import { x } from "~/lib/database"
```

**Exceptions acceptees :**
- `~/lib/config/predicateConstants` (pas de barrel pour config)
- `~/lib/config/chainConfig`
- `~/types/*` (import depuis fichier specifique, ex: `~/types/database`)

### 2. Architecture en couches

Verifie la direction des dependances :
```
Components → Hooks → Services → Utils → Config → Infrastructure
```

**Violations a detecter :**
- Component qui importe directement un service (`~/lib/services`) sans passer par un hook
- Hook qui contient de la logique metier (doit deleguer au service)
- Component qui fait des appels `chrome.runtime.sendMessage` directement
- Service qui importe un hook

### 3. CSS Conventions

- **Pas de couleurs hardcodees** — utiliser les CSS variables (`var(--color-primary)`, `var(--color-text-primary)`, etc.)
- **Pas de valeurs magiques** pour spacing — utiliser `var(--spacing-sm)`, `var(--spacing-md)`, etc.
- **BEM-like naming** : `.block-name`, `.block-name__element`, `.block-name.modifier`
- **Glassmorphism** pour les cartes : `backdrop-filter: blur()` + `rgba` background + border semi-transparent
- **Transitions** via variables : `var(--transition-fast)`, `var(--transition-normal)`
- **Z-index** respecte la hierarchie : base(1) → nav(3) → overlay(5) → header(100) → modal(999) → tooltip(9999)

### 4. Address Handling

- **GraphQL** : `_ilike` pour `account_id` (JAMAIS `_eq` — EIP-55 checksummed)
- **Comparaisons** : toujours `.toLowerCase()` des deux cotes
- **Storage keys** : toujours lowercase — `getWalletKey("key", wallet.toLowerCase())`
- **On-chain** : toujours checksummed via `getAddress()`

### 5. Predicate Constants

- **Jamais de duplication** de predicate IDs/labels dans les hooks ou components
- Tout doit venir de `~/lib/config/predicateConstants`
- Pour les queries on-chain, utiliser `INTENTION_PREDICATE_LABELS_WITH_LEGACY` (trailing space)

### 6. Component States

Chaque composant doit gerer 3 etats :
- **Loading** : indicateur visuel (spinner, skeleton, texte)
- **Empty** : message informatif quand pas de donnees
- **Content** : affichage normal des donnees

### 7. Race Conditions

- Hooks async doivent avoir un guard `useRef(false)` ou `fetchInFlight`
- Pas de `setState` apres un `await` sans verifier que le composant est toujours monte
- Les services utilisent le pattern in-flight guard

### 8. Modal Pattern

- Toujours `createPortal(<Modal />, document.body)`
- State machine : Form → Processing → Success/Error
- Props : `isOpen`, `onClose`, `onSubmit`, `isProcessing`, `transactionSuccess`, `transactionError`
- Overlay click-to-close : `onClick={(e) => e.target === e.currentTarget && onClose()}`

### 9. Hook Patterns

- Hooks sont des **thin wrappers** — pas de logique metier
- Result interface **toujours exportee** et explicite
- Callbacks : `on<Action>` pour les props, `handle<Action>` pour les internes
- Logger au niveau module : `const logger = createHookLogger("MonHook")`

### 10. GraphQL Patterns

- `atoms` n'a PAS de champ `id` — utiliser `term_id`
- `shares` filtre avec `_gt: "0"` (string, pas number)
- Pas de fetch all pour compter — utiliser `_aggregate`
- Fragments reutilises depuis `src/fragments/`

### 11. Blockchain Specifics

- `curveId = 1n` pour creation et votes, `curveId = 2n` pour deposits reguliers
- Toujours `simulate` avant `execute` pour les transactions
- Attendre 3s apres une transaction pour que l'indexer traite (`setTimeout`)

### 12. Formatting (Prettier)

- Pas de point-virgule (`semi: false`)
- Double quotes (`"`, pas `'`)
- Pas de trailing comma
- `printWidth: 80`

## Format de sortie

Pour chaque probleme trouve :

```
### [CRITIQUE|WARNING|SUGGESTION] — Titre court

**Fichier :** `chemin/vers/fichier.ts:ligne`
**Regle :** Nom de la regle violee
**Probleme :** Description precise
**Correction :**
\```typescript
// Avant
code problematique

// Apres
code corrige
\```
```

## Resume final

Termine par un tableau recapitulatif :

| Severite | Count | Categories |
|----------|-------|------------|
| CRITIQUE | X | ... |
| WARNING | X | ... |
| SUGGESTION | X | ... |

**Verdict :** APPROVE / REQUEST CHANGES / NEEDS DISCUSSION
