---
name: design
description: Reference complete du design system Sofia. Glassmorphism, CSS variables (50+), BEM naming, typography Montserrat/Gotu, modal state machine, animations, z-index hierarchy. Utilise cette skill quand tu ecris du CSS ou crees un composant UI.
allowed-tools: Read, Grep, Glob
---

# Design System Sofia

Theme **toujours dark**, **glassmorphism**, CSS variables, CSS pur (pas de Tailwind inline, pas de CSS-in-JS).

Source de verite : `extension/components/styles/Global.css`

## Reference material

- Pour la liste complete des 50+ CSS variables (couleurs, spacing, shadows, etc.) voir [tokens.md](tokens.md)
- Pour les patterns CSS copier-coller (cards, boutons, modals, avatars, inputs, animations) voir [patterns.md](patterns.md)

## Regles imperatives

1. **JAMAIS de couleurs hardcodees** — toujours `var(--color-*)`
2. **JAMAIS de spacing en px brut** — toujours `var(--spacing-*)`
3. **TOUJOURS glassmorphism** pour les cartes (`backdrop-filter: blur()` + `rgba` background + border semi-transparent)
4. **TOUJOURS prefix webkit** pour backdrop-filter (`-webkit-backdrop-filter`)
5. **TOUJOURS transitions** sur les elements interactifs (`var(--transition-fast|normal|slow)`)
6. **TOUJOURS le state machine** pour les modals (Form → Processing → Success/Error)
7. **TOUJOURS `createPortal`** pour les modals (jamais inline dans le JSX)
8. Theme **TOUJOURS dark** — pas de light mode

## Naming BEM-like

```css
.group-bento-card { }               /* Block */
.group-bento-header { }             /* Element */
.group-bento-card.can-level-up { }  /* Modifier (second selecteur, pas --) */
.group-bento-card:hover { }         /* State */
```

Convention : `kebab-case` avec prefixe du composant.

## Tokens essentiels (resume)

| Category | Variables | Exemple |
|----------|-----------|---------|
| Couleur primaire | `--color-primary` | `#C7866C` (tan chaud) |
| Texte | `--color-text-primary` | `#F2DED6` |
| Background | `--color-bg-glass` | `rgba(0,0,0,0.8)` |
| Bordure | `--color-border-light` | `rgba(255,255,255,0.1)` |
| Spacing | `--spacing-xs` → `--spacing-6xl` | `4px` → `60px` |
| Radius | `--radius-sm` → `--radius-full` | `4px` → `50%` |
| Fonts | `--font-family-primary` | Montserrat |
| Display | `--font-family-display` | Gotu (cursive) |
| Z-index | `--z-base` → `--z-tooltip` | `1` → `9999` |

## CSS Variables dynamiques (React)

```tsx
<div style={{
  "--accent-color": color,
  "--level-color": levelColor
} as React.CSSProperties}>
  <div className="card" /> {/* CSS utilise var(--accent-color) */}
</div>
```

## Responsive Breakpoints

```css
@media (max-width: 768px) { }  /* Tablettes */
@media (max-width: 480px) { }  /* Mobile */
@media (max-width: 420px) { }  /* Petit mobile */
@media (max-width: 360px) { }  /* Tres petit */
```

Ajustements : padding reduit, gap reduit, single column, fonts -1/-2 sizes, boutons full width.

## 34 fichiers CSS

Tous dans `extension/components/styles/`. Fichier global : `Global.css` (tokens + base elements).
