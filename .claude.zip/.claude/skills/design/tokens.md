# CSS Design Tokens — Sofia

Reference complete de toutes les CSS variables definies dans `extension/components/styles/Global.css`.

## Fonts

| Variable | Valeur | Usage |
|----------|--------|-------|
| `--font-family-primary` | `'Montserrat', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif` | Tout le body text |
| `--font-family-display` | `'Gotu', cursive` | Headers decoratifs, reward amounts |

## Typography Scale

| Variable | Size | Usage |
|----------|------|-------|
| `--font-size-xs` | 10px | Captions, labels mineurs |
| `--font-size-sm` | 12px | Small text, metadata |
| `--font-size-base` | 14px | Body text (defaut) |
| `--font-size-lg` | 16px | Sous-titres |
| `--font-size-xl` | 18px | Titres de section |
| `--font-size-2xl` | 24px | Grands headers |
| `--font-size-3xl` | 28px | Titres de page |

**Font weights** : 400 (regular), 500 (medium, boutons), 600 (semi-bold, headers), 700 (bold, CTA)

## Couleurs

### Palette principale
```css
--color-primary: #C7866C        /* Tan chaud — accent principal */
--color-primary-dark: #372118   /* Brun fonce */
--color-primary-light: #F2DED6  /* Creme */
--color-secondary: #945941      /* Rouille */
--color-accent: #A6AF6B         /* Vert sauge */
--color-hover: #FFB3C4          /* Rose hover */
--color-hover-light: #FFE078    /* Jaune clair hover */
```

### Texte
```css
--color-text-primary: #F2DED6
--color-text-secondary: #FBF7F5
--color-text-dark: #050505
--color-text-muted: rgba(255,255,255,0.8)
--color-text-very-muted: rgba(255,255,255,0.6)
--color-text-placeholder: rgba(255,255,255,0.5)
```

### Backgrounds (Glassmorphism)
```css
--color-bg-glass: rgba(0,0,0,0.8)
--color-bg-glass-light: rgba(255,255,255,0.05)
--color-bg-glass-lighter: rgba(255,255,255,0.1)
--color-bg-dark: rgba(14,14,14,0.15)
--color-bg-overlay: rgba(26,26,26,0.95)
```

### Bordures
```css
--color-border-glass: rgba(255,255,255,0.08)
--color-border-light: rgba(255,255,255,0.1)
--color-border-lighter: rgba(255,255,255,0.125)
--color-border-very-light: rgba(255,255,255,0.05)
--color-border-muted: rgba(242,222,214,0.2)
```

### Status
```css
--color-success: #22c55e
--color-error: #ef4444
--color-warning: #f59e0b
--color-info: #60a5fa
```

### Gradient
```css
--color-gradient-button: linear-gradient(135deg, #D790C7 0%, #d37cbf 20%, #ffc6b0 50%, #ffa7b1 80%, #cea2fd 100%)
```

## Spacing Scale

```css
--spacing-xs: 4px
--spacing-sm: 8px
--spacing-md: 12px
--spacing-lg: 16px
--spacing-xl: 20px
--spacing-2xl: 24px
--spacing-3xl: 30px
--spacing-4xl: 40px
--spacing-6xl: 60px
```

## Border Radius

```css
--radius-sm: 4px
--radius-md: 8px
--radius-lg: 12px
--radius-xl: 20px
--radius-full: 50%
```

## Shadows

```css
--shadow-glass: 0 4px 24px rgba(0,0,0,0.2)
--shadow-heavy: 0 8px 32px rgba(0,0,0,0.3)
--shadow-light: 0 2px 6px rgba(0,0,0,0.2)
--shadow-primary: 0 4px 16px rgba(219,107,62,0.3)
--shadow-button: 0 4px 12px rgba(212,165,116,0.3)
--shadow-button-hover: 0 6px 16px rgba(212,165,116,0.4)
--shadow-inset: inset 0 1px 0 rgba(255,255,255,0.2)
--shadow-inset-light: inset 0 1px 0 rgba(255,255,255,0.1)
```

## Transitions

```css
--transition-fast: all 0.2s ease
--transition-normal: all 0.3s ease
--transition-slow: all 0.5s ease
```

## Backdrop Filters

```css
--backdrop-blur: blur(10px)
--backdrop-blur-light: blur(5px)
--backdrop-blur-heavy: blur(20px)
--backdrop-saturate: saturate(100%)
```

## Component Sizes

```css
--size-icon-sm: 16px
--size-icon-md: 20px
--size-icon-lg: 24px
--size-button-height: 60px
--size-nav-height: 60px
```

## Z-Index Hierarchy

```
9999  --z-tooltip     Tooltips
999   --z-modal       Modals, overlays
100   --z-header      Fixed headers
5     --z-overlay     Semi-modals
3     --z-nav         Bottom navigation
1     --z-base        Defaut
```
