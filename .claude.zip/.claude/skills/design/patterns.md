# Component CSS Patterns — Sofia

Patterns CSS copier-coller pour les composants Sofia.

## Glassmorphism Card

Pattern de base pour TOUTE carte :

```css
.ma-card {
  background: rgba(0, 0, 0, 0.14);
  backdrop-filter: blur(50px) saturate(100%);
  -webkit-backdrop-filter: blur(50px) saturate(100%);
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 12px;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.5),
              inset 0 1px 0 rgba(255, 255, 255, 0.5);
  transition: all 0.3s ease;
}

.ma-card:hover {
  background-color: rgba(255, 255, 255, 0.08);
  border-color: rgba(255, 255, 255, 0.486);
  transform: translateY(-2px);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.3),
              inset 0 1px 0 rgba(255, 255, 255, 0.2);
}
```

Utilise par : `.echo-card`, `.category-card`, `.recommendation-card`, `.feed-item-container`

## Bouton standard

```css
.btn {
  padding: var(--spacing-sm) var(--spacing-lg);
  border-radius: var(--radius-sm);
  border: 1px solid var(--color-border-light);
  background: var(--color-bg-glass);
  color: var(--color-text-primary);
  cursor: pointer;
  font-weight: 500;
  transition: var(--transition-fast);
  display: inline-flex;
  align-items: center;
  gap: var(--spacing-xs);
}

.btn:hover:not(:disabled) {
  background: var(--color-bg-glass-lighter);
  border-color: var(--color-primary);
  transform: translateY(-1px);
}

.btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
```

Variantes : `.btn.primary`, `.btn.secondary`, `.btn.success`, `.btn.error`, `.btn.small`, `.btn.full-width`

## Bouton iridescent (CTA principal)

```css
.iridescence-btn {
  background: linear-gradient(135deg, #D790C7 0%, #d37cbf 20%, #ffc6b0 50%, #ffa7b1 80%, #cea2fd 100%);
  background-size: 200% 200%;
  animation: orb-gradient 20s ease infinite;
  box-shadow: 0 8px 32px rgba(236, 72, 153, 0.4);
  border: none;
  color: white;
  font-weight: 600;
}
```

## Modal (State Machine)

Flow : `Form → Processing (SofiaLoader) → Success/Error → Reward (optionnel) → Close`

```css
.modal-overlay {
  position: fixed;
  top: 0; left: 0; right: 0; bottom: 0;
  background: rgba(0, 0, 0, 0.8);
  z-index: 10000;
  display: flex;
  align-items: center;
  justify-content: center;
}

.modal-content {
  background: linear-gradient(to bottom, #060504, #101010);
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 24px;
  max-width: 500px;
  max-height: 90vh;
  overflow-y: auto;
  animation: modalAppear 0.2s ease-out;
}

@keyframes modalAppear {
  from { opacity: 0; transform: scale(0.95) translateY(-10px); }
  to { opacity: 1; transform: scale(1) translateY(0); }
}
```

### Success card (avec reward)

```css
.modal-success-card {
  border-radius: 16px;
  background: linear-gradient(145deg, #1a1a1a, #0d0d0d);
  border: 1px solid rgba(255, 255, 255, 0.08);
}

.modal-success-card-glow {
  height: 2px;
  background: linear-gradient(90deg, transparent, rgba(212, 175, 55, 0.8), transparent);
  box-shadow: 0 0 15px rgba(212, 175, 55, 0.4);
}

.reward-amount {
  font-size: 32px;
  font-family: 'Gotu', cursive;
  background: linear-gradient(180deg, #fcd34d, #f59e0b 40%, #d97706);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}
```

## Avatar

```css
.avatar { border-radius: 50%; overflow: hidden; flex-shrink: 0; }
.avatar-small { width: 32px; height: 32px; }
.avatar-medium { width: 48px; height: 48px; }
.avatar-large { width: 64px; height: 64px; }
.avatar-fallback {
  background: linear-gradient(135deg, rgba(200, 134, 108, 0.3), rgba(200, 134, 108, 0.1));
}
```

## Input/Form

```css
.input {
  width: 100%;
  padding: var(--spacing-sm) var(--spacing-md);
  border-radius: var(--radius-md);
  border: 1px solid var(--color-border-light);
  background: var(--color-bg-glass);
  color: var(--color-text-primary);
  font-size: var(--font-size-base);
  transition: var(--transition-fast);
}

.input:focus {
  outline: none;
  border-color: var(--color-primary);
  box-shadow: 0 0 0 2px rgba(199, 134, 108, 0.2);
}

.input::placeholder { color: var(--color-text-placeholder); }
```

## Animations

### Entrance (cards)
```css
@keyframes cardEnter {
  from { opacity: 0; transform: translateY(10px) scale(0.95); }
  to { opacity: 1; transform: translateY(0) scale(1); }
}
```

### Glow/Pulse (notifications)
```css
@keyframes quest-glow {
  from { box-shadow: 0 0 8px rgba(255, 215, 0, 0.25); }
  to { box-shadow: 0 0 12px rgba(255, 215, 0, 0.4); }
}
```

### Spin (loading)
```css
@keyframes modalSpin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
```

### Iridescent gradient
```css
@keyframes orb-gradient {
  0% { background-position: 0% 50%; }
  50% { background-position: 100% 50%; }
  100% { background-position: 0% 50%; }
}
```

## Scrollbar (cachee partout)

```css
* {
  scrollbar-width: none;
  -ms-overflow-style: none;
}
*::-webkit-scrollbar { display: none; }
```
