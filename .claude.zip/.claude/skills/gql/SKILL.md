---
name: gql
description: Conventions GraphQL du projet Sofia (Intuition indexer). Patterns de queries, fragments, pagination, codegen, et les pieges specifiques (term_id vs id, _ilike vs _eq, shares string, legacy labels). Utilise quand tu travailles avec des queries GraphQL.
allowed-tools: Read, Grep, Glob, Bash(cd */packages/graphql && pnpm codegen)
argument-hint: [action: new-query|review|codegen]
---

# GraphQL — Sofia / Intuition

Tu es un expert des conventions GraphQL du projet Sofia. Le backend GraphQL est l'indexer Intuition (Hasura).

## Fichiers cles

- Queries : `extension/packages/graphql/src/queries/*.graphql`
- Fragments : `extension/packages/graphql/src/fragments/*.graphql`
- Codegen config : `extension/packages/graphql/codegen.yml`
- Generated : `extension/packages/graphql/src/generated/index.ts`
- Client : `extension/lib/clients/intuitionGraphqlClient.ts`

## Workflow codegen

Apres avoir modifie un fichier `.graphql` :
```bash
cd extension/packages/graphql && pnpm codegen
```

Cela genere :
- Types TypeScript pour toutes les operations
- React Query v5 hooks : `useGetAtoms()`, `useGetTriplesInfinite()`
- DocumentNodes : `GetAtomsDocument`, `GetTriplesDocument`
- Query keys pour l'invalidation de cache

## Naming conventions

| Pattern | Exemples | Usage |
|---------|----------|-------|
| `Get<Entity>` | `GetAtoms`, `GetTriples` | Liste principale paginee |
| `Get<Entity>WithPositions` | `GetAtomsWithPositions` | Liste + positions utilisateur |
| `Get<Entity>Count` | `GetAtomsCount` | Count-only |
| `Find<Entity>` | `FindAtomIds`, `FindTriples` | Lookups utilitaires |
| `Search<Domain>` | `GlobalSearch` | Operations de recherche |

## Template de query paginee

```graphql
query GetMyEntities(
  $limit: Int
  $offset: Int
  $orderBy: [my_entities_order_by!]
  $where: my_entities_bool_exp
) {
  total: my_entities_aggregate(where: $where) {
    aggregate { count }
  }
  my_entities(
    limit: $limit
    offset: $offset
    order_by: $orderBy
    where: $where
  ) {
    ...MyEntityFragment
  }
}
```

**Toujours** : `_aggregate` separe pour le count + query principale pour les nodes.

## Fragments (11 fragments)

| Fragment | Purpose |
|----------|---------|
| `AtomMetadata` | Atom basique + `AtomValue` (person/thing/org/account) |
| `AtomVaultDetails` | Vault info avec positions |
| `TripleMetadata` | Subject/predicate/object atoms + vault |
| `TripleVaultDetails` | Term + counter_term vaults |
| `PositionDetails` | Position complete avec vault/atom/triple imbriques |
| `PositionFields` | Champs de position simplifies |
| `VaultDetails` | Details vault basiques |
| `FollowMetadata` | Triple avec vault positions pour follows |

**Regle :** Toujours reutiliser les fragments existants. Ne JAMAIS dupliquer les selections de champs.

## Filtres courants

```graphql
# Adresse : TOUJOURS _ilike (EIP-55 checksummed)
account_id: { _ilike: $address }

# Shares : String comparison (PAS numerique)
shares: { _gt: "0" }

# Predicats : IDs ou labels avec _in
predicate_id: { _in: $predicateIds }
predicate: { label: { _in: $labels } }

# Hostname pattern
object: { label: { _ilike: $hostnameLike } }

# Conditions multiples
_and: [
  { predicate_id: { _eq: $predicateId } }
  { positions: { account_id: { _ilike: $address }, shares: { _gt: "0" } } }
]
```

## Utilisation avec le client pagine

```typescript
import { MyQueryDocument, type MyQueryQuery } from "@0xsofia/graphql"
import { intuitionGraphqlClient } from "~/lib/clients"

// Extraire le type de resultat
type MyResult = MyQueryQuery["my_entities"][number]

// Fetch pagine
const results = await intuitionGraphqlClient.fetchAllPages<MyResult>(
  MyQueryDocument,
  { predicateLabels: CERTIFICATION_PREDICATE_LABELS, userAddress },
  "my_entities",  // cle du resultat
  100,            // taille de page
  100             // max pages
)
```

## PIEGES CRITIQUES

### 1. `atoms` n'a PAS de champ `id`
Utilise `term_id` a la place. Le codegen ECHOUERA si tu utilises `id` sur le type `atoms`.

### 2. `_ilike` vs `_eq` pour les adresses
L'indexer stocke les adresses en EIP-55 (mixed case). Utilise TOUJOURS `_ilike` pour les `account_id`.

**Exception :** `FindTriples` utilise `_eq` pour les positions — ne PAS modifier (utilise ailleurs).

### 3. `shares` est un string
```graphql
# CORRECT
shares: { _gt: "0" }

# FAUX
shares: { _gt: 0 }
```

### 4. Legacy trailing space
Les anciens predicats on-chain ont un trailing space : `"visits for learning "`.
Utilise `INTENTION_PREDICATE_LABELS_WITH_LEGACY` quand tu queries des donnees on-chain.

### 5. Pas de fetch-all pour compter
```graphql
# CORRECT — utiliser _aggregate
total: triples_aggregate(where: $where) {
  aggregate { count }
}

# FAUX — fetcher tous les nodes pour compter
```

### 6. Ne jamais filtrer client-side
Pousse TOUS les filtres dans la clause `where`. Le client ne doit pas re-filtrer.

## Anti-patterns

- **Jamais hardcoder** curve IDs, adresses, limites — utiliser des variables
- **Jamais dupliquer** des fragments — reutiliser ceux de `src/fragments/`
- **Jamais utiliser `_ilike`** pour des lookups exacts sur champs indexes — utiliser `_eq`
- **Utiliser les fonctions DB** quand disponibles : `following()`, `positions_from_following()`, `search_positions_on_subject()`

## Actions

Si `$ARGUMENTS` contient :
- **`new-query`** : Guide la creation d'une nouvelle query avec le template et les conventions
- **`review`** : Review les queries GraphQL existantes/modifiees pour les anti-patterns
- **`codegen`** : Lance le codegen et verifie que tout compile
