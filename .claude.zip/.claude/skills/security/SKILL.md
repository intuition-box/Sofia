---
name: security
description: Audit de securite automatique pour Sofia. Scanne les patterns dangereux (XSS, injection, tokens en clair, origins non validees, postMessage wildcard). Lance ce skill regulierement ou avant un release.
allowed-tools: Read, Grep, Glob, Bash(git diff*, wc *, sort *)
argument-hint: [fichier-ou-dossier-optionnel]
context: fork
agent: general-purpose
---

# Security Audit — Sofia Extension

Tu es un auditeur securite specialise extensions Chrome et crypto/Web3. Tu scannes le codebase Sofia pour detecter les vulnerabilites connues et les regressions.

Si `$ARGUMENTS` est fourni, concentre le scan sur ce fichier/dossier. Sinon, scanne tout `extension/`.

## Scans automatiques

Execute chacun de ces scans et rapporte les violations trouvees.

### Scan 1 — Code Injection (CRITIQUE)

Cherche les patterns dangereux d'injection de code :

**innerHTML / dangerouslySetInnerHTML :**
Cherche `innerHTML` et `dangerouslySetInnerHTML` dans tous les fichiers `.ts`, `.tsx` du dossier `extension/`.
Exclure les `node_modules/` et `build/`.

**Resultat attendu** : ZERO occurrences. Toute utilisation est une vulnerabilite XSS potentielle.

**eval / new Function :**
Cherche `eval(` et `new Function(` dans les memes fichiers.

**Resultat attendu** : ZERO occurrences. Si trouve, suggerer l'alternative safe.

**document.write :**
Cherche `document.write(` dans les content scripts.

**Resultat attendu** : ZERO occurrences.

### Scan 2 — Origin Validation (CRITIQUE)

**External message origins :**
Verifie que `chrome.runtime.onMessageExternal` valide TOUJOURS l'origin :
- Cherche `onMessageExternal.addListener` dans `extension/background/`
- Verifie que chaque handler commence par une validation d'origin contre `ALLOWED_EXTERNAL_ORIGINS`
- Verifie que les origins non autorisees recoivent un `sendResponse({ success: false })`

**postMessage origins :**
Cherche `window.postMessage(` dans `extension/contents/`.
Pour chaque occurrence, verifier le deuxieme argument :
- `"*"` = **VULNERABILITE** — n'importe quelle page peut intercepter le message
- `window.location.origin` = OK

**Resultat attendu** : aucun `postMessage` avec `"*"` comme origin.

**addEventListener("message") validation :**
Pour chaque `window.addEventListener("message"` dans `extension/contents/`, verifier que :
- `event.source === window` est verifie (emetteur = meme fenetre)
- `event.data?.type` est verifie avant traitement

### Scan 3 — Token & Secret Storage (HAUTE)

**OAuth tokens :**
Cherche les patterns de stockage de tokens dans `extension/background/oauth/`.
Verifier :
- Les tokens sont stockes avec une cle prefixee par wallet (`oauth_token_{platform}_{wallet}`)
- Pas de tokens en dur dans le code
- Les tokens expires sont supprimes ou refresh

**Secrets en clair :**
Cherche `apiKey`, `api_key`, `secret`, `password`, `private_key`, `PRIVY` dans les fichiers `.ts` et `.env*` de `extension/`.
Exclure :
- `types/` (declarations de type)
- `constants.ts` (noms de params a filtrer)
- `.env.example` (templates)

**Resultat attendu** : aucun secret hardcode. Tous les secrets via `process.env.PLASMO_PUBLIC_*`.

### Scan 4 — Wallet Security (HAUTE)

**RPC method whitelist :**
Cherche `ALLOWED_RPC_METHODS` dans `extension/contents/walletBridge.ts`.
Verifier que la whitelist ne contient PAS de methodes dangereuses :
- `eth_sign` (DANGEREUX — permet de signer n'importe quoi)
- `wallet_addEthereumChain` sans validation des parametres
- `debug_*` methodes

Verifier que toute methode non listee est refusee avec `code: -32601`.

**Provider selection :**
Verifier que `selectProviderByName` est le seul moyen de selectionner un provider.
`selectProviderByAddress` doit etre deprecate ou supprime.

**Wallet address logging :**
Cherche les patterns de logging qui pourraient exposer une adresse complete :
- `logger.*(.*walletAddress` — doit utiliser `.slice(0, 8)` ou similaire
- `console.log(.*address` — ne devrait pas exister en production

### Scan 5 — URL Security (MOYENNE)

**URL construction par concatenation :**
Cherche les patterns de construction d'URL non-safe :
- `` `http${...}` `` ou `` `https://${variable}` `` dans les fichiers `.ts`
- Verifier que `new URL()` est utilise pour construire des URLs a partir de user input

**Exceptions acceptees :**
- `getFaviconUrl()` dans `formatters.ts` (utilise `new URL()` avec try/catch)
- `getAuthUrl()` (construction interne, pas de user input)
- URLs de config (`chainConfig.*.ts`)

**Sensitive URL filtering :**
Verifier que `SENSITIVE_URL_PATTERNS` dans `background/constants.ts` couvre :
- `login`, `auth`, `signin`, `signup`, `password`, `bank`, `payment`, `checkout`
- `oauth`, `token`, `session`, `CAPTCHA`
- `privy.intuition.systems`, `embedded-wallets`

**Tracking param stripping :**
Verifier que `TRACKING_URL_PARAMS` couvre les principaux trackers :
- UTM params (`utm_source`, `utm_medium`, `utm_campaign`)
- Platform trackers (`gclid`, `fbclid`, `msclkid`)

### Scan 6 — Content Script Isolation (MOYENNE)

**World MAIN :**
Cherche `world: "MAIN"` dans `extension/contents/`.

Seul `walletBridge.ts` devrait utiliser `world: "MAIN"`. Tout autre script en MAIN est suspect — il a acces au DOM de la page et peut etre manipule par du JS malveillant.

**all_frames: true :**
Cherche `all_frames: true` dans `extension/contents/`.

Verifier que chaque script avec `all_frames: true` :
- A une raison valide (tracking dans les iframes)
- Ne fait pas d'operations sensibles dans les iframes (pas de wallet, pas de tokens)

### Scan 7 — Permissions Manifest (BASSE)

Lire les permissions dans `extension/package.json` (section `manifest`).

Verifier :
- Pas de `webRequest` ou `webRequestBlocking` (permet d'intercepter tout le trafic)
- Pas de `cookies` (permet de voler des cookies)
- Pas de permissions inutilisees (chaque permission a un usage justifie)

Permissions actuelles attendues :
`storage`, `history`, `tabs`, `activeTab`, `sidePanel`, `bookmarks`, `identity`, `offscreen`

**host_permissions :**
`<all_urls>` est necessaire pour les content scripts. Verifier qu'il n'y a pas d'autres host_permissions inutiles.

### Scan 8 — Input Sanitization (BASSE)

**Modals avec input utilisateur :**
Cherche `<input` et `<textarea` dans `extension/components/modals/`.
Pour chaque input :
- Verifier que `type="number"` est utilise pour les montants
- Verifier qu'il y a une validation (min, max, pattern, ou validation custom)
- Verifier que la valeur n'est jamais inseree directement dans du HTML

**Labels et titres affiches :**
Les `atom.label`, `atom.value.thing.url`, et autres donnees on-chain sont affichees dans l'UI.
Verifier qu'elles passent par des composants React (JSX echap automatiquement) et jamais par `innerHTML`.

## Format de rapport

Pour chaque scan, rapporter :

```
### Scan N — Nom (SEVERITE)

**Statut** : PASS / FAIL / WARNING

**Violations trouvees :**
- [CRITIQUE] fichier:ligne — description du probleme
- [WARNING] fichier:ligne — pattern suspect a verifier

**Recommandations :**
- Action corrective si FAIL
```

## Resume final

Apres tous les scans, generer un tableau :

| Scan | Severite | Statut | Violations |
|------|----------|--------|------------|
| 1. Code Injection | CRITIQUE | PASS/FAIL | N |
| 2. Origin Validation | CRITIQUE | PASS/FAIL | N |
| 3. Token Storage | HAUTE | PASS/FAIL | N |
| 4. Wallet Security | HAUTE | PASS/FAIL | N |
| 5. URL Security | MOYENNE | PASS/FAIL | N |
| 6. Content Script Isolation | MOYENNE | PASS/FAIL | N |
| 7. Permissions Manifest | BASSE | PASS/FAIL | N |
| 8. Input Sanitization | BASSE | PASS/FAIL | N |

**Verdict global** : SECURE / NEEDS ATTENTION / VULNERABILITIES FOUND

## Vulnerabilites connues (a surveiller)

Ces issues ont ete identifiees et doivent etre surveillees :

1. **`walletRelay.ts` — postMessage avec `"*"`** : utilise `window.postMessage(msg, "*")` au lieu de `window.location.origin`. Risque : une page malveillante pourrait intercepter les messages wallet. Mitigation : le message est interne (ISOLATED → MAIN world), le risque est limite mais devrait etre corrige.

2. **`localhost:3000` dans ALLOWED_EXTERNAL_ORIGINS** : origin de dev hardcode. Devrait etre conditionne par `process.env.NODE_ENV` ou supprime en prod.

3. **localStorage pour InterestAnalysisService** : donnees d'interet cachees en clair dans localStorage. Pas critique (pas de secrets), mais devrait utiliser chrome.storage pour coherence.

4. **`<all_urls>` + `web_accessible_resources`** : les ressources de l'extension sont accessibles a toutes les pages. Minimiser les ressources exposees.
