# Chrome Storage Decision Guide — Sofia

## Arbre de decision

```
Quelle donnee stocker ?
    │
    ├─ Etat temporaire de session (wallet courant, type)
    │   → chrome.storage.session
    │   → Cle : brute ("walletAddress", "walletType")
    │   → Survit : restart service worker ✓, fermeture navigateur ✗
    │
    ├─ Donnee persistante simple (Gold, XP, flags, tokens)
    │   → chrome.storage.local
    │   → Cle : prefixee wallet (getWalletKey("discovery_gold", wallet.toLowerCase()))
    │   → Survit : restart ✓, fermeture navigateur ✓
    │
    ├─ Donnee structuree complexe (groups, triplets, bookmarks)
    │   → IndexedDB (sofiaDB)
    │   → Cle : auto-increment ou domain (selon le store)
    │   → Survit : restart ✓, fermeture navigateur ✓
    │
    └─ Cache temporaire non critique
        → localStorage (seulement InterestAnalysisService)
        → Usage deconseille dans le service worker (non disponible)
```

## Cles par area

### chrome.storage.session

| Cle | Type | Usage |
|-----|------|-------|
| `walletAddress` | string | Adresse wallet connecte |
| `walletType` | string | Type de provider (MetaMask, Rabby, etc.) |
| `pending_profile_view` | object | Intent de navigation deep link |

### chrome.storage.local

| Pattern de cle | Type | Usage |
|----------------|------|-------|
| `discovery_gold_{wallet}` | number | Gold gagne par discovery |
| `certification_gold_{wallet}` | number | Gold gagne par certification |
| `spent_gold_{wallet}` | number | Gold depense |
| `proxy_approved_{wallet}` | boolean | Approbation proxy SofiaFeeProxy |
| `oauth_token_{platform}_{wallet}` | UserToken | Tokens OAuth (5 plateformes) |
| `lastActiveWallet` | string | Dernier wallet actif (detect changement) |
| `signal_activity_dates_{wallet}` | string[] | Dates d'activite signal |
| `certification_activity_dates_{wallet}` | string[] | Dates certifications |
| `vote_activity_dates_{wallet}` | string[] | Dates de votes |
| `daily_vote_count_{wallet}` | number | Compteur votes du jour |
| `daily_vote_date_{wallet}` | string | Date du compteur |
| `pulse_launches_{wallet}` | number | Nombre de lancements pulse |
| `weekly_pulse_uses_{wallet}` | number | Utilisations pulse cette semaine |
| `weekly_pulse_start_{wallet}` | number | Debut de semaine pulse |

### IndexedDB (sofiaDB)

10 stores — voir skill `indexeddb` pour les details.

## Patterns de code

### Lecture/ecriture simple

```typescript
// Ecrire
await chrome.storage.local.set({ [key]: value })

// Lire (une cle)
const result = await chrome.storage.local.get([key])
const value = result[key] || defaultValue

// Lire (plusieurs cles)
const result = await chrome.storage.local.get([key1, key2, key3])
```

### Ecoute reactive (temps reel)

```typescript
// Dans un service (singleton)
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes[myKey]) {
    this.updateState({ value: changes[myKey].newValue })
  }
})

// Dans un hook (avec cleanup)
useEffect(() => {
  const listener = (changes: Record<string, chrome.storage.StorageChange>) => {
    if (changes[key]) setValue(changes[key].newValue || 0)
  }
  chrome.storage.onChanged.addListener(listener)
  return () => chrome.storage.onChanged.removeListener(listener)
}, [key])
```

### Cache avec TTL

```typescript
const CACHE_DURATION = 120_000  // 2 min
const cacheKey = getWalletKey("progress_cache", wallet)
const timestampKey = getWalletKey("progress_timestamp", wallet)

const result = await chrome.storage.local.get([cacheKey, timestampKey])
if (result[cacheKey] && Date.now() - (result[timestampKey] || 0) < CACHE_DURATION) {
  return result[cacheKey]  // Cache hit
}
// ... fetch fresh data
await chrome.storage.local.set({
  [cacheKey]: freshData,
  [timestampKey]: Date.now()
})
```

## Anti-patterns

- **NE PAS** utiliser `localStorage` dans le service worker (indisponible)
- **NE PAS** stocker des objets complexes dans chrome.storage (limites de serialisation)
- **NE PAS** oublier `.toLowerCase()` sur les adresses dans les cles
- **NE PAS** ecouter `chrome.storage.onChanged` sans filtrer par `area`
- **NE PAS** stocker des secrets en clair sans prefixe wallet (isolation)
