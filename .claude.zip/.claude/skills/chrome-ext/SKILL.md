---
name: chrome-ext
description: Reference complete des patterns Chrome Extension MV3 et Plasmo dans Sofia. Service worker lifecycle, message passing, content scripts, chrome.storage, side panel. Consulte cette skill quand tu travailles avec les APIs Chrome ou les content scripts.
allowed-tools: Read, Grep, Glob
context: fork
agent: general-purpose
---

# Chrome Extension MV3 & Plasmo — Reference Sofia

Tu es un expert Chrome Extension MV3 et Plasmo. Tu connais les specificites de Sofia : service worker lifecycle, message passing async, content scripts multi-world, et chrome.storage patterns.

## Architecture Extension Sofia

```
sidepanel.tsx (React UI)
    ↕ chrome.runtime.sendMessage / onMessage
background/index.ts (Service Worker MV3)
    ↕ chrome.runtime.sendMessage / onMessage
contents/*.ts (5 Content Scripts)
    ↕ window.postMessage (walletBridge ↔ walletRelay)
Page web (wallet providers, Privy auth)
```

## 1. Service Worker MV3 — Lifecycle

### Initialisation (`background/index.ts`)

```
chrome.runtime.onInstalled → checkExistingConnection()
    → init()
        ├─ initializeThemeIconManager()
        ├─ setupMessageHandlers() ← guard: handlersRegistered
        ├─ getWalletAddress() from chrome.storage.session
        ├─ initializeBadgeCount() (fire-and-forget)
        └─ Return si pas de wallet
```

### Guard anti-duplication (CRITIQUE)

Le service worker MV3 peut etre tue apres ~30s d'inactivite, puis redemarre par Chrome. Les listeners sont re-enregistres a chaque reveil.

```typescript
// background/messageHandlers.ts
let handlersRegistered = false

export function setupMessageHandlers(): void {
  if (handlersRegistered) {
    logger.warn("[messageHandlers] Handlers already registered, skipping")
    return
  }
  handlersRegistered = true
  // ... register listeners
}
```

**Regle** : Toujours garder ce pattern pour les message handlers.

### Mort du service worker — Consequences

Le service worker peut mourir a tout moment. Consequences :

| Pattern | Impact | Solution Sofia |
|---------|--------|----------------|
| Variables en memoire | Perdues | `chrome.storage.session` ou IndexedDB |
| `setTimeout` | Annule | `chrome.alarms` (pas encore migre) |
| Listeners | Re-enregistres | Guard `handlersRegistered` |
| Connections WebSocket | Perdues | Reconnexion au reveil |

**SessionTracker** flush immediatement (threshold=1) au lieu de batcher :
```typescript
const BUFFER_SIZE_THRESHOLD = 1  // MV3 worker peut mourir a tout moment
```

### Restauration au reveil

```typescript
// background/index.ts
async function checkExistingConnection() {
  const address = await getWalletAddress()
  if (address) {
    logger.info('Restoring wallet session', { address })
  }
  await init()
}
checkExistingConnection()  // Appele au demarrage du worker
```

Lit le wallet depuis `chrome.storage.session` (survit au restart du worker, pas a la fermeture du navigateur).

## 2. Message Passing — Patterns

### Types de messages (60 types)

Definis dans `types/messages.ts`. Discriminated union sur `message.type`.

### Pattern Async (CRITIQUE)

```typescript
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  (async () => {
    switch (message.type) {
      // Fire-and-forget (pas de reponse attendue)
      case "PAGE_DATA":
        pageDataService.handlePageData(message)
        break

      // Request-response async
      case "GET_INTENTION_GROUPS":
        try {
          const groups = await groupManager.getAllGroups()
          sendResponse({ success: true, groups })
        } catch (error) {
          sendResponse({ success: false, error: error.message })
        }
        return  // ← sendResponse sera appele dans le try/catch
    }
    sendResponse({ success: false, error: 'Unknown message type' })
  })().catch(error => {
    sendResponse({ success: false, error: error.message })
  })
  return true  // ← TOUJOURS return true pour autoriser sendResponse async
})
```

**Regles** :
- `return true` en fin de listener = "je vais appeler `sendResponse` de facon asynchrone"
- Sans `return true`, Chrome ferme le canal et `sendResponse` ne fait rien
- `break` = fire-and-forget (pas de reponse)
- Pattern IIFE async `.catch()` pour eviter les rejections non gerees

### External Messages (Privy, OAuth)

```typescript
// background/messageHandlers.ts
const ALLOWED_EXTERNAL_ORIGINS = [
  'https://sofia.intuition.box',
  'http://localhost:3000'  // Dev only
]

chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
  // SECURITE : valider l'origin en premier
  const isAllowed = sender.origin && ALLOWED_EXTERNAL_ORIGINS.some(
    allowed => sender.origin!.startsWith(allowed)
  )
  if (!isAllowed) {
    sendResponse({ success: false, error: 'Untrusted origin' })
    return true
  }
  // Handler WALLET_CONNECTED, WALLET_DISCONNECTED, OAUTH_TOKEN_SUCCESS
})
```

Necessite `externally_connectable` dans le manifest :
```json
"externally_connectable": {
  "matches": ["http://localhost:3000/*", "https://sofia.intuition.box/*"]
}
```

### Envoyer un message depuis un hook

```typescript
// Pattern standard
const response = await chrome.runtime.sendMessage({
  type: "GET_INTENTION_GROUPS"
})
if (response.success) setGroups(response.groups)

// Fire-and-forget (ignorer les erreurs)
chrome.runtime.sendMessage({ type: "ECHOES_UPDATED" }).catch(() => {})
```

### Ecouter les messages dans un hook (avec cleanup)

```typescript
useEffect(() => {
  const handleMessage = (message: any) => {
    if (message.type === "GROUPS_UPDATED") loadGroups()
  }
  chrome.runtime.onMessage.addListener(handleMessage)
  return () => chrome.runtime.onMessage.removeListener(handleMessage)
}, [loadGroups])
```

## 3. Content Scripts — 5 Scripts

| Script | `all_frames` | `world` | Responsabilite |
|--------|-------------|---------|----------------|
| `tracking.ts` | `true` | ISOLATED | Tracking URL (delai 3s, detection SPA) |
| `pageAnalyzer.ts` | `false` | ISOLATED | Extraction metadata page |
| `walletBridge.ts` | `false` | **MAIN** | Detection wallet EIP-6963 |
| `walletRelay.ts` | `false` | ISOLATED | Bridge messages ISOLATED ↔ MAIN |
| `pulseCollector.ts` | `false` | ISOLATED | Collecte metriques d'attention |

### Config Plasmo

```typescript
import type { PlasmoCSConfig } from "plasmo"

export const config: PlasmoCSConfig = {
  matches: ["<all_urls>"],
  all_frames: false,    // true = aussi dans les iframes
  // world: "MAIN"      // Seulement walletBridge.ts
}
```

Plasmo injecte automatiquement les scripts selon la config exportee. Pas besoin de les declarer dans le manifest.

### World MAIN vs ISOLATED

- **ISOLATED** (defaut) : Pas acces a `window.ethereum`, mais acces a `chrome.runtime`
- **MAIN** : Acces a `window.ethereum` et providers, mais PAS acces a `chrome.runtime`

C'est pourquoi on a **deux** scripts pour le wallet :
1. `walletBridge.ts` (MAIN) → detecte les providers EIP-6963, execute les appels RPC
2. `walletRelay.ts` (ISOLATED) → recoit les messages de background via `chrome.runtime`, les forwarde via `window.postMessage`

### Pattern Wallet Bridge

```
Background (chrome.runtime.sendMessage)
    ↓
walletRelay.ts (ISOLATED) — recoit via chrome.runtime.onMessage
    ↓ window.postMessage({ type: "SOFIA_WALLET_REQUEST" })
walletBridge.ts (MAIN) — ecoute via window.addEventListener("message")
    ↓ provider.request({ method, params })
Wallet Provider (MetaMask, Rabby, etc.)
    ↓ resultat
walletBridge.ts (MAIN) — window.postMessage({ type: "SOFIA_WALLET_RESPONSE" })
    ↓
walletRelay.ts (ISOLATED) — ecoute via window.addEventListener("message")
    ↓ sendResponse(result)
Background
```

### Tracking — Delai 3s et detection SPA

```typescript
// contents/tracking.ts
const MIN_TIME_BEFORE_TRACK = 3000  // 3s avant d'enregistrer la visite

// Detection SPA : verifie le changement d'URL toutes les secondes
setInterval(() => {
  if (window.location.href !== lastUrl) {
    lastUrl = window.location.href
    // Re-initialiser le tracking
  }
}, 1000)
```

## 4. Chrome Storage — 3 niveaux

| Area | Persistence | Quota | Usage Sofia |
|------|-------------|-------|-------------|
| `chrome.storage.session` | Jusqu'au restart navigateur | 10 MB | `walletAddress`, `walletType`, navigation intents |
| `chrome.storage.local` | Permanent | 10 MB (unlimited avec permission) | Gold, XP, OAuth tokens, proxy approval, quest progress |
| `IndexedDB` | Permanent | ~illimite | Groups, triplets, navigation, bookmarks (10 stores) |

### Wallet-Prefixed Keys (isolation par wallet)

```typescript
import { getWalletKey } from "~/lib/utils"

// TOUJOURS lowercase pour les cles
const key = getWalletKey("discovery_gold", walletAddress.toLowerCase())
// → "discovery_gold_0xabc..."

await chrome.storage.local.set({ [key]: value })
const result = await chrome.storage.local.get([key])
```

### Ecouter les changements (reactif)

```typescript
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "session") return
  if (changes.walletAddress) {
    const newWallet = changes.walletAddress.newValue || null
    handleWalletChange(newWallet)
  }
})
```

Ce pattern est utilise par :
- `useWalletFromStorage` — ecoute `session.walletAddress`
- `DiscoveryScoreService` — re-fetch au changement de wallet
- `useGoldSystem` — ecoute `local.discovery_gold_*`, `certification_gold_*`, `spent_gold_*`

### Deep Link via Session Storage

Pour naviguer vers un profil quand le side panel s'ouvre :
```typescript
// Background : stocker l'intent
await chrome.storage.session.set({
  pending_profile_view: { termId, label, walletAddress }
})

// Side panel : verifier au chargement
const result = await chrome.storage.session.get("pending_profile_view")
if (result.pending_profile_view) {
  navigateTo("user-profile", result.pending_profile_view)
  await chrome.storage.session.remove("pending_profile_view")
}
```

## 5. Plasmo Specifiques

### Versions et config

- **Plasmo** : 0.90.5
- **Manifest** : V3 (chrome-mv3-dev)
- **Build** : `plasmo dev` (testnet) / `plasmo build --no-minify` (prod)
- **Path alias** : `~` → `extension/` root (tsconfig paths)

### Permissions manifest (`package.json`)

```json
"permissions": ["storage", "history", "tabs", "activeTab", "sidePanel", "bookmarks", "identity", "offscreen"],
"host_permissions": ["<all_urls>", "https://auth.privy.io/*"],
"side_panel": { "default_path": "sidepanel.html" }
```

### Side Panel (`sidepanel.tsx`)

Point d'entree React avec providers :
```
QueryClientProvider → WagmiProvider → RouterProvider → SidePanelContent
```

Navigation custom via `useRouter()` (pas react-router) :
```typescript
const { currentPage, navigateTo, goBack } = useRouter()
navigateTo("user-profile", { termId, label, walletAddress })
```

### Web Accessible Resources

```json
"web_accessible_resources": [{
  "resources": ["public/spline-background.webm", "assets/*", "components/ui/*.png", "components/ui/quick_action/*.svg"],
  "matches": ["<all_urls>"]
}]
```

## 6. Gotchas et pieges

### HTTPS obligatoire pour les transactions

Le transport `custom(provider)` de viem necessite une page HTTPS active (content script injection). `viemClients.ts` force l'ouverture d'un onglet HTTPS avant toute transaction :
```typescript
await ensureHttpsTabForWallet()
```

### Wallet change = clear IndexedDB

Quand le wallet change, les donnees locales sont effacees :
```typescript
const { lastActiveWallet } = await chrome.storage.local.get('lastActiveWallet')
if (lastActiveWallet && lastActiveWallet.toLowerCase() !== walletAddress.toLowerCase()) {
  await IntentionGroupsService.clearAll()
}
```

### Timeout wallet requests (30s)

Les requetes wallet dans `walletRelay.ts` ont un timeout de 30s pour eviter les requetes bloquantes.

### Badge extension

```typescript
await chrome.action.setBadgeText({ text: count.toString() })
await chrome.action.setBadgeBackgroundColor({ color: '#dc3545' })
```

### Ne PAS utiliser dans le service worker

- `localStorage` / `sessionStorage` → utiliser `chrome.storage`
- `window` / `document` → n'existent pas dans le service worker
- `setTimeout` longue duree → utiliser `chrome.alarms`
- Etat en memoire persistant → flush vers chrome.storage ou IndexedDB

## 7. Recettes

### Ajouter un nouveau type de message

1. Ajouter le type dans `types/messages.ts` (union `MessageType`)
2. Ajouter le handler dans `background/messageHandlers.ts` (switch)
3. Envoyer depuis hook/component : `chrome.runtime.sendMessage({ type: "MON_TYPE", data })`
4. Si async : `return true` dans le handler

### Ajouter un nouveau content script

1. Creer `contents/monScript.ts`
2. Exporter la config Plasmo :
   ```typescript
   export const config: PlasmoCSConfig = {
     matches: ["<all_urls>"],
     all_frames: false
   }
   ```
3. Plasmo le detecte automatiquement au `pnpm dev`

### Debugger le service worker

1. `chrome://extensions/` → Extension Sofia → "Inspect views: service worker"
2. Console du service worker pour voir les logs
3. Le worker se tue apres 30s sans activite → garder la console ouverte le maintient en vie
