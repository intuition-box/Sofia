---
name: indexeddb
description: Reference complete IndexedDB pour Sofia. 10 stores, 9 data services, schema migrations, key patterns, et recettes. Consulte cette skill quand tu travailles avec le stockage persistant local.
allowed-tools: Read, Grep, Glob
context: fork
agent: general-purpose
---

# IndexedDB — Reference Sofia

Tu es un expert IndexedDB pour Sofia. Tu connais les 10 stores, les 9 data services, les patterns de cles, et les strategies de migration.

## Architecture

```
Hooks / Components
    ↓ chrome.runtime.sendMessage (pour les groups)
    ↓ ou import direct (pour les bookmarks)
Background Services (GroupManager, TripletStorageService, BadgeService)
    ↓
Data Services (9 classes statiques dans indexedDB-methods.ts)
    ↓
SofiaIndexedDB singleton (sofiaDB — CRUD generiques)
    ↓
IndexedDB API (Browser)
```

**Deux modes d'acces :**
- **Via Chrome messages** : hooks → background → services → DB (groups, certification, level-up)
- **Import direct** : hooks → data services (bookmarks, recommendations)

## Database Config

- **Nom** : `sofia-extension-db`
- **Version** : 8 (incrementee pour renommer ELIZA_DATA → TRIPLETS_DATA)
- **Singleton** : `export const sofiaDB = new SofiaIndexedDB()`
- **Connection** : Promise cache pour eviter les ouvertures multiples

## Les 10 Stores

| Store | Key Path | Auto-Inc | Index | Usage |
|-------|----------|----------|-------|-------|
| `TRIPLETS_DATA` | `id` | oui | `messageId` (unique), `timestamp`, `type` | Messages Sofia, etats triplets, details publies |
| `NAVIGATION_DATA` | `id` | oui | `url`, `lastUpdated`, `visitData.visitCount` | Historique visites URL |
| `USER_PROFILE` | `id` | non | `lastUpdated` | Singleton `id='profile'` |
| `USER_SETTINGS` | `id` | non | `lastUpdated` | Singleton `id='settings'` |
| `SEARCH_HISTORY` | `id` | oui | `timestamp`, `query` | Requetes de recherche |
| `BOOKMARK_LISTS` | `id` | non | `name`, `createdAt`, `updatedAt` | Listes de bookmarks |
| `BOOKMARKED_TRIPLETS` | `id` | non | `sourceType`, `sourceId`, `addedAt` | Triplets bookmarkes individuels |
| `RECOMMENDATIONS` | `walletAddress` | non | `timestamp`, `lastUpdated` | Recommendations AI par wallet |
| `INTENTION_GROUPS` | `id` (=domain) | non | `domain` (unique), `level`, `createdAt`, `updatedAt` | Groupes d'intention par domaine |
| `USER_XP` | `id` | non | (aucun) | Singleton `id='user'` |

## Les 9 Data Services

Toutes les methodes sont **statiques** (pas d'instances).

### TripletsDataService

| Methode | Description |
|---------|-------------|
| `storeMessage(message, messageId?)` | Parse et stocke un message Sofia |
| `storeParsedMessage(parsedMessage, messageId?)` | Stocke des triplets parses |
| `getAllMessages()` | Tous les records |
| `getMessagesByType(type)` | Filtrer par index `type` |
| `getRecentMessages(limit=50)` | Tri par timestamp DESC, client-side |
| `deleteOldMessages(daysToKeep=30)` | Nettoyage par age |
| `storeTripletStates(states)` | Etats EchoesTab sous messageId special |
| `loadTripletStates()` | Charger les etats |
| `storePublishedTripletIds(ids)` | IDs publies |
| `addPublishedTripletId(id)` | Ajouter un ID publie |
| `storePublishedTriplet(details)` | Details d'un triplet publie (avec gestion de conflits) |
| `loadPublishedTriplets()` | Tous les details publies |
| `cleanupOldTripletRecords()` | Supprimer anciens formats conflictuels |
| `deleteMessage(messageId)` | Supprimer par messageId |
| `clearAll()` | Vider le store |

### NavigationDataService

| Methode | Description |
|---------|-------------|
| `storeVisitData(url, visitData)` | Upsert par URL (check index avant add/put) |
| `getVisitData(url)` | Recherche par index URL |
| `getAllVisitData()` | Toutes les visites |
| `getMostVisited(limit=10)` | Tri par visitCount DESC, client-side |
| `getRecentVisits(limit=20)` | Tri par lastVisitTime DESC, client-side |
| `clearAll()` | Vider le store |

### UserProfileService

| Methode | Description |
|---------|-------------|
| `saveProfile(photo?, bio?, url?)` | Singleton record `id='profile'` |
| `getProfile()` | Lire le singleton |
| `updateProfilePhoto(photoData)` | Update partiel |
| `updateBio(bio)` | Update partiel |
| `updateProfileUrl(url)` | Update partiel |

### UserSettingsService

| Methode | Description |
|---------|-------------|
| `saveSettings(settings)` | Merge avec existant, singleton `id='settings'` |
| `getSettings()` | Lire avec defaults si absent |
| `updateSetting(key, value)` | Update type d'un setting |

### SearchHistoryService

| Methode | Description |
|---------|-------------|
| `addSearch(query, results?)` | Upsert par query (deduplique) |
| `getRecentSearches(limit=20)` | Tri par timestamp DESC |
| `searchInHistory(term)` | Recherche substring client-side |
| `deleteOldSearches(daysToKeep=90)` | Nettoyage |
| `clearHistory()` | Vider |

### BookmarkService

| Methode | Description |
|---------|-------------|
| `createList(wallet, name, desc?)` | UUID genere comme cle |
| `getAllLists(wallet)` | Filtrer par wallet, tri updatedAt DESC |
| `getList(listId)` | Par cle primaire |
| `updateList(listId, updates)` | Nom/description |
| `deleteList(listId)` | **Cascade** : supprime les triplets associes puis la liste |
| `addTripletToList(listId, triplet, sourceInfo)` | Creer triplet + updater liste |
| `removeTripletFromList(listId, tripletId)` | Supprimer triplet + updater liste |
| `getTripletsByList(listId)` | Join manuel (get() sequentiels) |
| `getAllTriplets(wallet)` | Fetch listes → Set d'IDs → filtrer triplets |
| `searchTriplets(wallet, query)` | Recherche multi-champ client-side |

### RecommendationsService

| Methode | Description |
|---------|-------------|
| `saveRecommendations(wallet, raw, parsed)` | Wallet comme cle primaire |
| `getRecommendations(wallet)` | Lire par wallet |
| `areRecommendationsValid(wallet, maxAge=24h)` | Validation TTL |
| `updateRecommendations(wallet, newRaw, newParsed)` | Merge avec deduplication |
| `deleteRecommendations(wallet)` | Supprimer |
| `cleanupOldRecommendations(days=30)` | Nettoyage |

### IntentionGroupsService

| Methode | Description |
|---------|-------------|
| `getAllGroups()` | Toutes, tri updatedAt DESC |
| `getGroup(groupId)` | Par domain (domain = cle primaire) |
| `saveGroup(group)` | Upsert avec updatedAt automatique |
| `deleteGroup(groupId)` | Supprimer par domain |
| `clearAll()` | Vider (appele au changement de wallet) |

### UserXPService

| Methode | Description |
|---------|-------------|
| `getUserXP()` | Singleton `id='user'` |
| `saveUserXP(xp)` | Upsert avec lastUpdated |
| `initializeIfNeeded()` | Creer record par defaut si absent |

## Patterns de cles

### Singleton (record unique)

```typescript
// Cle fixe, un seul record dans le store
const PROFILE_KEY = "profile"
const SETTINGS_KEY = "settings"
const USER_XP_KEY = "user"

// Read-then-update
const existing = await sofiaDB.get(STORES.USER_PROFILE, "profile")
const updated = { ...existing, bio: newBio, lastUpdated: Date.now() }
await sofiaDB.put(STORES.USER_PROFILE, updated)
```

### Auto-increment (records multiples)

```typescript
// Cle generee par IndexedDB, recherche par index
const record = { messageId: "msg_123", content: data, timestamp: Date.now(), type: "parsed_message" }
await sofiaDB.add(STORES.TRIPLETS_DATA, record)
// → id auto-genere (1, 2, 3, ...)

// Recherche par index
const found = await sofiaDB.getByIndex(STORES.TRIPLETS_DATA, "messageId", "msg_123")
```

### Domain comme cle (groups)

```typescript
// Le domain EST la cle primaire
const group: IntentionGroupRecord = {
  id: "github.com",       // domain = id
  domain: "github.com",
  title: "GitHub",
  level: 1,
  urls: [...],
  // ...
}
await sofiaDB.put(STORES.INTENTION_GROUPS, group)

// Lecture directe par domain
const group = await sofiaDB.get(STORES.INTENTION_GROUPS, "github.com")
```

### Wallet comme cle (recommendations)

```typescript
// Wallet address (lowercase) = cle primaire
const record = {
  walletAddress: wallet.toLowerCase(),
  parsedRecommendations: [...],
  lastUpdated: Date.now()
}
await sofiaDB.put(STORES.RECOMMENDATIONS, record)
```

## Upsert Pattern

IndexedDB n'a pas d'upsert natif. Sofia utilise deux approches :

### Approche 1 : Check par index puis add/put

```typescript
// NavigationDataService.storeVisitData()
const existing = await sofiaDB.getByIndex(STORES.NAVIGATION_DATA, "url", url)
if (existing) {
  existing.visitData = mergeVisitData(existing.visitData, newVisitData)
  existing.lastUpdated = Date.now()
  await sofiaDB.put(STORES.NAVIGATION_DATA, existing)
} else {
  await sofiaDB.add(STORES.NAVIGATION_DATA, { url, visitData: newVisitData, lastUpdated: Date.now() })
}
```

### Approche 2 : put() directement (quand la cle est connue)

```typescript
// IntentionGroupsService.saveGroup()
group.updatedAt = Date.now()
await sofiaDB.put(STORES.INTENTION_GROUPS, group)
// put() ecrase si la cle existe, cree sinon
```

## Relations entre stores (join manuel)

Les bookmarks utilisent deux stores lies :

```typescript
// BOOKMARK_LISTS contient tripletIds: string[]
// BOOKMARKED_TRIPLETS contient les records individuels

// Join : lire la liste, puis fetch chaque triplet
async getTripletsByList(listId: string) {
  const list = await sofiaDB.get(STORES.BOOKMARK_LISTS, listId)
  if (!list?.tripletIds?.length) return []

  const triplets = []
  for (const id of list.tripletIds) {
    const triplet = await sofiaDB.get(STORES.BOOKMARKED_TRIPLETS, id)
    if (triplet) triplets.push(triplet)
  }
  return triplets
}
```

**Cascade delete** : supprimer les triplets AVANT la liste.

## Schema Migrations

### Pattern `onupgradeneeded`

```typescript
// lib/database/indexedDB.ts
request.onupgradeneeded = (event) => {
  const db = (event.target as IDBOpenDBRequest).result

  // Chaque store est cree SI il n'existe pas (idempotent)
  if (!db.objectStoreNames.contains(STORES.TRIPLETS_DATA)) {
    const store = db.createObjectStore(STORES.TRIPLETS_DATA, {
      keyPath: "id",
      autoIncrement: true
    })
    store.createIndex("messageId", "messageId", { unique: true })
    store.createIndex("timestamp", "timestamp", { unique: false })
    store.createIndex("type", "type", { unique: false })
  }
  // ... meme pattern pour les 9 autres stores
}
```

### Pour ajouter un nouveau store

1. **Incrementer** `DB_VERSION` dans `lib/database/indexedDB.ts`
2. **Ajouter** le nom dans `STORES` const
3. **Ajouter** `createObjectStore` dans `onupgradeneeded` (avec guard `!contains`)
4. **Creer** la classe service dans `lib/database/indexedDB-methods.ts`
5. **Exporter** depuis `lib/database/index.ts` barrel

### Pour ajouter un index a un store existant

```typescript
// Dans onupgradeneeded, APRES le guard
if (!db.objectStoreNames.contains(STORES.MY_STORE)) {
  // Creation initiale...
} else {
  // Migration : ajouter un index
  const tx = (event.target as IDBOpenDBRequest).transaction!
  const store = tx.objectStore(STORES.MY_STORE)
  if (!store.indexNames.contains("newIndex")) {
    store.createIndex("newIndex", "newField", { unique: false })
  }
}
```

## Types (`types/database.ts`)

### IntentionGroupRecord (le plus complexe)

```typescript
interface IntentionGroupRecord {
  id: string                          // domain (ex: "github.com")
  domain: string
  title: string
  createdAt: number
  updatedAt: number
  urls: GroupUrlRecord[]              // URLs du groupe
  level: number                       // Niveau du groupe (commence a 1)
  currentPredicate: string | null     // Predicat courant
  predicateHistory: PredicateChangeRecord[]
  totalAttentionTime: number
  totalCertifications: number
  dominantCertification: string | null
  amplifiedPredicate?: string | null
}

interface GroupUrlRecord {
  url: string
  title: string
  domain: string
  favicon?: string
  addedAt: number
  attentionTime: number
  certification: "work" | "learning" | "fun" | "inspiration" | "buying" | "music" | "trusted" | "distrusted" | null
  certifiedAt?: number
  removed: boolean
  oauthPredicate?: string
  oauthSource?: string
  isOnChain?: boolean
  onChainCertification?: string
}
```

## Performance

### Tri client-side (limitation actuelle)

Sofia charge tous les records puis trie en memoire :

```typescript
const all = await sofiaDB.getAll(STORES.NAVIGATION_DATA)
const sorted = all.sort((a, b) => b.lastUpdated - a.lastUpdated)
return sorted.slice(0, limit)
```

**Acceptable** tant que les datasets restent petits. Pour de gros volumes, utiliser `IDBKeyRange` :

```typescript
// Optimisation possible avec curseur + range
const range = IDBKeyRange.lowerBound(Date.now() - 7 * 24 * 3600 * 1000)
const recent = await sofiaDB.getAllByIndex(STORES.NAVIGATION_DATA, "lastUpdated", range)
```

### Pas d'expiration automatique

Les methodes `deleteOldMessages(daysToKeep)` et `deleteOldSearches(daysToKeep)` existent mais doivent etre appelees manuellement. Aucun nettoyage automatique n'est en place.

## Anti-patterns

- **NE PAS** oublier `DB_VERSION++` quand on modifie le schema
- **NE PAS** faire des reads synchrones (tout est async via Promises)
- **NE PAS** oublier le guard `!db.objectStoreNames.contains()` dans `onupgradeneeded`
- **NE PAS** stocker des Blobs/Files directement (serialisation limitee)
- **NE PAS** faire de joins complexes — IndexedDB n'est pas un SGBD relationnel
- **NE PAS** supprimer une liste de bookmarks sans supprimer ses triplets d'abord (cascade)
- **NE PAS** oublier `lastUpdated` / `updatedAt` dans les upserts
