---
name: arch-check
description: Scan automatique des violations d'architecture Sofia. Detecte les imports non-barrel, les appels directs de services depuis les components, les duplications de predicates, et les violations de couches. Lance ce skill regulierement pour garder le code propre.
allowed-tools: Read, Grep, Glob, Bash(git diff*, wc *, sort *)
context: fork
agent: general-purpose
---

# Architecture Validation — Sofia

Tu es un gardien de l'architecture Sofia. Scanne le codebase pour detecter les violations des regles architecturales.

## Scans automatiques

Execute chacun de ces scans et rapporte les violations trouvees.

### Scan 1 — Imports non-barrel (CRITIQUE)

Cherche les imports qui contournent les barrel files :

**Services :**
Cherche `from "~/lib/services/` dans tous les fichiers `.ts` et `.tsx` du dossier `extension/`.
Les seuls fichiers autorises a importer directement sont ceux DANS `lib/services/` eux-memes.

**Hooks :**
Cherche `from "~/hooks/use` dans tous les fichiers.
Les seuls fichiers autorises sont ceux DANS `hooks/`.

**Utils :**
Cherche `from "~/lib/utils/` dans tous les fichiers.
Les seuls fichiers autorises sont ceux DANS `lib/utils/`.

**Database :**
Cherche `from "~/lib/database/` (sauf `from "~/lib/database"`) dans les fichiers hors de `lib/database/`.

### Scan 2 — Components appelant des services directement

Cherche `from "~/lib/services"` dans les fichiers de `extension/components/`.
Les components ne doivent JAMAIS importer de services — ils doivent passer par les hooks.

**Exception :** Les fichiers dans `components/` qui sont des wrappers techniques (providers) peuvent importer des services.

### Scan 3 — Layering violations

Verifie que :
- `extension/lib/services/` n'importe JAMAIS depuis `~/hooks`
- `extension/lib/utils/` n'importe JAMAIS depuis `~/hooks` ni `~/lib/services`
- `extension/lib/config/` n'importe JAMAIS depuis `~/hooks`, `~/lib/services`, ni `~/lib/utils`

### Scan 4 — Predicate duplication

Cherche les predicate IDs/labels hardcodes en dehors de `predicateConstants.ts` :
- `"visits for work"`, `"visits for learning"`, `"visits for fun"`, etc.
- Les IDs hex de predicats (commence par `0x` et fait 66 chars)
- Les noms de predicats dans des arrays/objets locaux

**Accepte :** Les references a `PREDICATE_*` importes depuis `predicateConstants`.

### Scan 5 — Barrel completude

Verifie que chaque fichier dans ces dossiers est exporte par son barrel :
- `extension/lib/services/*.ts` → exporte dans `lib/services/index.ts`
- `extension/hooks/use*.ts` → exporte dans `hooks/index.ts`
- `extension/lib/utils/*.ts` → exporte dans `lib/utils/index.ts`

### Scan 6 — Address handling

Cherche les patterns dangereux :
- `account_id: { _eq:` dans les fichiers `.graphql` ou `.ts` (devrait etre `_ilike`)
- Comparaisons d'adresses sans `.toLowerCase()` : `=== walletAddress` ou `=== address`
- `atoms.id` dans les queries GraphQL (devrait etre `term_id`)

### Scan 7 — Service patterns

Verifie que chaque service dans `lib/services/` :
- A un export singleton (`export const monService = new MonServiceClass()`)
- Exporte aussi la classe (`export { MonServiceClass }`)
- Utilise `createServiceLogger` pour le logging

### Scan 8 — Hook patterns

Verifie que chaque hook dans `hooks/` :
- A une interface de resultat exportee (`export interface UseMonHookResult`)
- Utilise `createHookLogger` (optionnel mais recommande)
- N'excede pas ~200 lignes (thin wrapper)
- Ne contient pas de logique metier complexe (delegue au service)

## Format de rapport

```
## Rapport d'Architecture Sofia

### Resume
| Scan | Status | Violations |
|------|--------|------------|
| Imports non-barrel | ✅/❌ | X |
| Services dans components | ✅/❌ | X |
| Layering | ✅/❌ | X |
| Predicate duplication | ✅/❌ | X |
| Barrel completude | ✅/❌ | X |
| Address handling | ✅/❌ | X |
| Service patterns | ✅/❌ | X |
| Hook patterns | ✅/❌ | X |

### Violations detaillees

#### [SCAN_NAME] — [FICHIER:LIGNE]
**Violation :** Description
**Correction :** Ce qu'il faut faire
```

### Score global

- **A** (0 violations) — Architecture exemplaire
- **B** (1-3 warnings) — Quelques ajustements mineurs
- **C** (violations critiques) — Refactoring necessaire
- **D** (violations multiples) — Architecture compromise

Presente toujours le score en fin de rapport.
