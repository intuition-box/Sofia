---
name: implement
description: Implemente une nouvelle feature en suivant l'architecture Sofia. Pipeline complete - plan, service, hook, component, CSS, barrel exports. Respecte les conventions du projet (glassmorphism, thin hooks, singleton services, barrel imports).
allowed-tools: Read, Write, Edit, Bash, Grep, Glob
argument-hint: [description-de-la-feature]
disable-model-invocation: true
context: fork
agent: general-purpose
---

# Feature Implementation — Sofia

Implemente la feature suivante : **$ARGUMENTS**

Tu dois suivre la pipeline d'implementation Sofia dans l'ordre. Ne saute aucune phase.

## Phase 0 — Exploration & Plan

Avant d'ecrire du code :

1. **Lis l'architecture** : comprends les fichiers existants qui seront impactes
2. **Cherche des patterns similaires** dans le codebase — ne reinvente pas la roue
3. **Identifie les couches a toucher** :
   - Nouveau service necessaire ? → `lib/services/`
   - Nouveau hook necessaire ? → `hooks/`
   - Nouveau component ? → `components/`
   - Nouveau CSS ? → `components/styles/`
   - Nouvelle query GraphQL ? → `packages/graphql/src/queries/`
   - Nouveau type ? → `types/`
   - Nouveau message Chrome ? → `types/messages.ts` + `background/messageHandlers.ts`

4. **Presente le plan** a l'utilisateur avant d'implementer

## Phase 1 — Types (si besoin)

Definis les types dans `extension/types/` :

```typescript
// types/maFeature.ts
export interface MaFeatureData {
  id: string
  // ...
}

// Pour les props de component
export interface MaFeatureProps {
  data: MaFeatureData
  onAction: (id: string) => void
  isLoading?: boolean
}

// Pour les resultats de hook
export interface UseMaFeatureResult {
  data: MaFeatureData | null
  loading: boolean
  error: string | null
  doAction: (id: string) => Promise<void>
}
```

Conventions :
- `Props` suffix pour les props de composant
- `Result` suffix pour les retours de hook
- Interfaces pour les shapes d'objets
- Type aliases pour les unions

## Phase 2 — Service (si logique metier)

Cree le service dans `extension/lib/services/` :

```typescript
// lib/services/MaFeatureService.ts
import { createServiceLogger } from "../utils/logger"

const logger = createServiceLogger("MaFeatureService")

class MaFeatureServiceClass {
  // Pattern A: Class + singleton (le plus courant)

  async fetchData(walletAddress: string): Promise<MaFeatureData | null> {
    try {
      // logique metier ici
      logger.info("Data fetched", { walletAddress })
      return data
    } catch (error) {
      logger.error("Failed to fetch", error)
      return null  // Services retournent null, jamais throw (sauf blockchain)
    }
  }
}

export const maFeatureService = new MaFeatureServiceClass()
export { MaFeatureServiceClass }
```

**IMPORTANT** : Ajoute au barrel `lib/services/index.ts` :
```typescript
export { MaFeatureServiceClass, maFeatureService } from './MaFeatureService'
```

Si le service a un etat partage (reactif), utilise le protocole `useSyncExternalStore` :
- `getSnapshot` et `subscribe` en arrow functions (pour preserver `this`)
- Lazy init dans `subscribe` (pas dans le constructeur)
- `updateState()` prive qui notifie les listeners

## Phase 3 — Hook (thin wrapper)

Cree le hook dans `extension/hooks/` :

```typescript
// hooks/useMaFeature.ts
import { useState, useCallback, useEffect } from "react"
import { createHookLogger } from "~/lib/utils"
import { maFeatureService } from "~/lib/services"
import { useWalletFromStorage } from "./useWalletFromStorage"

const logger = createHookLogger("useMaFeature")

export interface UseMaFeatureResult {
  data: MaFeatureData | null
  loading: boolean
  error: string | null
  refetch: () => Promise<void>
}

export const useMaFeature = (): UseMaFeatureResult => {
  const { walletAddress } = useWalletFromStorage()
  const [data, setData] = useState<MaFeatureData | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const refetch = useCallback(async () => {
    if (!walletAddress) return
    setLoading(true)
    setError(null)
    try {
      const result = await maFeatureService.fetchData(walletAddress)
      setData(result)
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Unknown error"
      logger.error("Fetch failed", err)
      setError(msg)
    } finally {
      setLoading(false)
    }
  }, [walletAddress])

  useEffect(() => { refetch() }, [refetch])

  return { data, loading, error, refetch }
}
```

**IMPORTANT** : Ajoute au barrel `hooks/index.ts` :
```typescript
export { useMaFeature } from "./useMaFeature"
export type { UseMaFeatureResult } from "./useMaFeature"
```

Regles du hook :
- **Thin wrapper** — delegue TOUT au service
- Race condition guard avec `useRef(false)` si async complexe
- Logger au niveau module
- Gestion null wallet au debut

## Phase 4 — Component

Cree le composant dans `extension/components/` :

```typescript
// components/pages/MaFeaturePage.tsx (ou components/ui/, components/modals/, etc.)
import { useState, useCallback, useMemo } from "react"

import { useMaFeature, useWalletFromStorage } from "~/hooks"
import { calculateLevel, formatBalance } from "~/lib/utils"

import "../styles/MaFeature.css"

interface MaFeaturePageProps {
  onNavigate?: (page: string) => void
}

const MaFeaturePage = ({ onNavigate }: MaFeaturePageProps) => {
  const { walletAddress } = useWalletFromStorage()
  const { data, loading, error, refetch } = useMaFeature()

  // Callbacks internes : handle<Action>
  const handleClick = useCallback((id: string) => {
    // ...
  }, [])

  // 3 ETATS OBLIGATOIRES :

  // 1. Loading
  if (loading) {
    return <div className="ma-feature-loading">Chargement...</div>
  }

  // 2. Error
  if (error) {
    return <div className="ma-feature-error">{error}</div>
  }

  // 3. Empty
  if (!data) {
    return <div className="ma-feature-empty">Aucune donnee</div>
  }

  // 4. Content
  return (
    <div className="ma-feature">
      {/* contenu */}
    </div>
  )
}

export default MaFeaturePage
```

Regles du composant :
- JAMAIS d'import direct de services — toujours via hooks
- Props interface explicite
- `on<Action>` pour les callbacks en props, `handle<Action>` pour les internes
- Gestion des 3 etats : loading, error/empty, content
- `useMemo` pour les calculs couteux
- Modals via `createPortal(modal, document.body)`
- Processing tracking avec `Set<string>` pour les listes

## Phase 5 — CSS

Cree le fichier CSS dans `extension/components/styles/` :

```css
/* components/styles/MaFeature.css */

/* Utilise les CSS variables du design system */
.ma-feature {
  padding: var(--spacing-lg);
}

/* Cards : glassmorphism obligatoire */
.ma-feature-card {
  background: rgba(0, 0, 0, 0.14);
  backdrop-filter: blur(50px) saturate(100%);
  -webkit-backdrop-filter: blur(50px) saturate(100%);
  border: 1px solid var(--color-border-light);
  border-radius: var(--radius-lg);
  padding: var(--spacing-md);
  transition: var(--transition-normal);
}

.ma-feature-card:hover {
  background-color: rgba(255, 255, 255, 0.08);
  border-color: rgba(255, 255, 255, 0.486);
  transform: translateY(-2px);
  box-shadow: var(--shadow-heavy);
}

/* Texte */
.ma-feature-title {
  font-size: var(--font-size-lg);
  font-weight: 600;
  color: var(--color-text-primary);
  font-family: var(--font-family-primary);
}

.ma-feature-subtitle {
  font-size: var(--font-size-sm);
  color: var(--color-text-muted);
}

/* Boutons */
.ma-feature-btn {
  padding: var(--spacing-sm) var(--spacing-lg);
  border-radius: var(--radius-sm);
  border: 1px solid var(--color-border-light);
  background: var(--color-bg-glass);
  color: var(--color-text-primary);
  cursor: pointer;
  font-weight: 500;
  transition: var(--transition-fast);
}

.ma-feature-btn:hover:not(:disabled) {
  background: var(--color-bg-glass-lighter);
  border-color: var(--color-primary);
  transform: translateY(-1px);
}

/* Etats */
.ma-feature-loading,
.ma-feature-empty,
.ma-feature-error {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: var(--spacing-4xl);
  color: var(--color-text-muted);
  font-size: var(--font-size-sm);
}
```

Regles CSS :
- **JAMAIS** de couleurs hardcodees — toujours `var(--color-*)`
- **JAMAIS** de spacing en px brut — toujours `var(--spacing-*)`
- **BEM-like** : `.ma-feature`, `.ma-feature-card`, `.ma-feature-card:hover`
- **Glassmorphism** pour toutes les cartes (backdrop-filter + rgba + border)
- **Transitions** via `var(--transition-fast|normal|slow)`
- **Z-index** respecte la hierarchie globale
- Theme toujours dark (pas de media query prefers-color-scheme)

## Phase 6 — Barrel Exports & Integration

Verifie que TOUT est exporte dans les barrels :
1. Service → `lib/services/index.ts`
2. Hook → `hooks/index.ts`
3. Types → fichier type specifique dans `types/`
4. Util → `lib/utils/index.ts` (si nouveau)

## Phase 7 — Validation automatique

Une fois le code ecrit, lance les agents de validation :

1. **quality-checker** — verifie barrel imports, architecture en couches, hook thickness, patterns de components, address handling, predicate constants
2. **design-validator** — verifie CSS variables, glassmorphism, BEM naming, z-index, transitions, modal pattern

Si un agent rapporte des issues **BLOQUANTES**, corrige-les avant de presenter le resultat.

## Phase 8 — Checklist finale

- [ ] Tous les imports utilisent les barrel files
- [ ] Le service est un singleton exporte
- [ ] Le hook est un thin wrapper (< 100 lignes idealement)
- [ ] Le component gere loading/error/empty
- [ ] Le CSS utilise les variables du design system
- [ ] Les callbacks suivent la convention on*/handle*
- [ ] Pas de logique metier dans le component
- [ ] Formatting Prettier (no semi, double quotes, no trailing comma)
- [ ] quality-checker : PASS
- [ ] design-validator : CONFORME (si CSS modifie)
