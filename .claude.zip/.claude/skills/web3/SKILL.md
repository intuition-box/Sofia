---
name: web3
description: Patterns Viem, transactions, fee calculation, wallet connection, et address handling dans Sofia. Complement du skill blockchain. Consulte cette skill quand tu ecris du code qui interagit avec la blockchain ou les wallets.
allowed-tools: Read, Grep, Glob
context: fork
agent: general-purpose
---

# Web3 / Viem — Reference Sofia

Tu es un expert Viem et interactions blockchain pour Sofia. Tu connais le dual client setup, le pattern simulate-execute-wait, les fee calculations, et le wallet bridge EIP-6963.

**Complement du skill `blockchain`** : ce skill couvre les patterns de code Viem/Wagmi, le skill `blockchain` couvre les concepts Intuition (atoms, triples, vaults, predicates).

## 1. Dual Client Architecture

Sofia utilise **deux clients viem** separes :

### Public Client (read-only)

```typescript
// lib/clients/viemClients.ts
export const getPublicClient = () => {
  return createPublicClient({
    chain: SELECTED_CHAIN,
    transport: http(SELECTED_CHAIN.rpcUrls.default.http[0])
  })
}
```

Usage : gas estimation, `readContract`, `waitForTransactionReceipt`. Pas de wallet necessaire.

### Wallet Client (write)

```typescript
export const getClients = async () => {
  // 1. Garantir un onglet HTTPS (requis pour content script injection)
  await ensureHttpsTabForWallet()

  // 2. Re-selectionner le provider depuis chrome.storage.session
  const storage = await chrome.storage.session.get(["walletType"])
  if (storage.walletType) {
    await selectProviderByName(storage.walletType)
  }

  // 3. Recuperer le provider et les accounts
  const provider = await getWalletProvider()
  const accounts = await provider.request({ method: "eth_requestAccounts" })

  // 4. Creer le wallet client avec transport custom
  const walletClient = createWalletClient({
    account: accounts[0],
    chain: SELECTED_CHAIN,
    transport: custom(provider)  // Passe par le wallet bridge
  })

  // 5. Verifier/switcher la chain
  const chainId = await walletClient.getChainId()
  if (chainId !== SELECTED_CHAIN.id) {
    await provider.request({
      method: "wallet_switchEthereumChain",
      params: [{ chainId: `0x${SELECTED_CHAIN.id.toString(16)}` }]
    })
  }

  return { walletClient, publicClient: getPublicClient() }
}
```

**Points critiques :**
- `ensureHttpsTabForWallet()` : le transport `custom()` passe par un content script → necessite HTTPS
- `selectProviderByName()` : re-selectionne a chaque appel car le content script peut perdre son etat
- `custom(provider)` : transport qui route les appels RPC via le wallet bridge (walletBridge.ts ↔ walletRelay.ts)

### Wagmi — Usage minimal

Sofia n'utilise PAS les hooks Wagmi (`useAccount`, `useWriteContract`, etc.). Le config existe uniquement pour des dependances :

```typescript
// lib/config/wagmi.ts
export const wagmiConfig = createConfig({
  chains: [SELECTED_CHAIN],
  transports: { [SELECTED_CHAIN.id]: http(SELECTED_CHAIN.rpcUrls.default.http[0]) }
})
```

**Regle** : utiliser `getClients()` et les methodes viem brutes. Pas de hooks Wagmi.

## 2. Pattern Simulate → Execute → Wait

Toute ecriture on-chain suit ce pattern en 5 etapes :

```typescript
async function writeOnChain(args: any): Promise<Result> {
  const { walletClient, publicClient } = await getClients()
  const contractAddress = BlockchainService.getContractAddress()

  // Etape 1 : CALCULER les frais
  const totalCost = await BlockchainService.getTotalDepositCost(depositAmount)

  // Etape 2 : SIMULER la transaction (dry run, detecte les reverts)
  await publicClient.simulateContract({
    address: contractAddress as Address,
    abi: SofiaFeeProxyAbi,
    functionName: "deposit",
    args: [receiver, termId, curveId, minShares],
    value: totalCost,
    account: walletClient.account
  })

  // Etape 3 : EXECUTER la transaction (ouvre le popup wallet)
  const hash = await walletClient.writeContract({
    address: contractAddress as Address,
    abi: SofiaFeeProxyAbi,
    functionName: "deposit",
    args: [receiver, termId, curveId, minShares],
    value: totalCost,
    chain: SELECTED_CHAIN,
    maxFeePerGas: BLOCKCHAIN_CONFIG.MAX_FEE_PER_GAS,
    maxPriorityFeePerGas: BLOCKCHAIN_CONFIG.MAX_PRIORITY_FEE_PER_GAS,
    account: walletClient.account
  })

  // Etape 4 : ATTENDRE le receipt
  const receipt = await publicClient.waitForTransactionReceipt({ hash })

  // Etape 5 : VERIFIER le status
  if (receipt.status !== "success") {
    throw new Error(`Transaction failed: ${receipt.status}`)
  }

  return { success: true, txHash: hash }
}
```

**Pourquoi simuler d'abord ?**
- Detecte les reverts sans depenser de gas
- Meilleur message d'erreur (le revert reason est lisible)
- Evite l'experience utilisateur "j'ai signe mais ca a echoue"

## 3. Contrats et ABIs

### Sofia Fee Proxy (`ABI/SofiaFeeProxy.ts`)

Toutes les ecritures passent par le proxy Sofia qui collecte des frais.

| Fonction | Usage | Parametres |
|----------|-------|------------|
| `createAtoms` | Creer N atoms | `(receiver, data[], assets[], curveId)` |
| `createTriples` | Creer N triples | `(receiver, subjectIds[], predicateIds[], objectIds[], assets[], curveId)` |
| `deposit` | Deposer sur un vault existant | `(receiver, termId, curveId, minShares)` |
| `depositBatch` | Batch deposits | `(receiver, termIds[], curveIds[], assets[], minShares[])` |
| `calculateDepositFee` | Calcul fee (read) | `(depositCount, totalDeposit)` |
| `getTotalDepositCost` | Cout total deposit (read) | `(depositAmount)` |
| `getTotalCreationCost` | Cout total creation (read) | `(depositCount, totalDeposit, multiVaultCost)` |

### MultiVault (`ABI/MultiVault.ts`)

Contrat principal Intuition. Le proxy l'appelle en interne.

| Fonction | Usage |
|----------|-------|
| `previewDeposit(termId, curveId, assets)` | Preview shares recues |
| `getShares(account, termId, curveId)` | Shares detenues par un user |
| `getAtomCost()` | Cout de creation d'un atom |
| `getTripleCost()` | Cout de creation d'un triple |
| `calculateAtomId(encodedData)` | ID deterministe d'un atom |
| `calculateTripleId(sub, pred, obj)` | ID deterministe d'un triple |
| `isTermCreated(termId)` | Verifier si un term existe |

## 4. Fee Calculation

### Fonctions du BlockchainService

```typescript
// lib/services/blockchainService.ts

// Fee pour un deposit simple
static async getTotalDepositCost(depositAmount: bigint): Promise<bigint> {
  return await publicClient.readContract({
    address: PROXY_ADDRESS,
    abi: SofiaFeeProxyAbi,
    functionName: "getTotalDepositCost",
    args: [depositAmount]
  })
}

// Fee pour creation d'atoms/triples
static async getTotalCreationCost(
  depositCount: number,      // Nombre de deposits non-zero
  totalDeposit: bigint,      // Somme des montants
  multiVaultCost: bigint     // Cout MultiVault (atomCost/tripleCost * count + totalDeposit)
): Promise<bigint> {
  return await publicClient.readContract({
    address: PROXY_ADDRESS,
    abi: SofiaFeeProxyAbi,
    functionName: "getTotalCreationCost",
    args: [BigInt(depositCount), totalDeposit, multiVaultCost]
  })
}
```

### Calcul du cout total pour un triple

```typescript
// CREATION (triple n'existe pas)
const tripleCost = await BlockchainService.getTripleCost()
const depositAmount = customWeight ?? MIN_TRIPLE_DEPOSIT  // 0.01 TRUST
const multiVaultCost = tripleCost + depositAmount
const totalCost = await BlockchainService.getTotalCreationCost(1, depositAmount, multiVaultCost)

// DEPOSIT (triple existe deja)
const depositAmount = customWeight ?? feeCost
const totalCost = await BlockchainService.getTotalDepositCost(depositAmount)
```

### Structure des frais Sofia

- Fee fixe : 0.1 TRUST par deposit
- Fee variable : 5% du montant
- Pour creation : fee fixe + 5% du cout MultiVault

## 5. Constantes Blockchain

```typescript
// Curve IDs
const CREATION_CURVE_ID = 1n     // Linear — pour creation atoms/triples ET votes
const DEPOSIT_CURVE_ID = 2n      // Progressive — pour deposits reguliers

// Montants minimum
const MIN_ATOM_DEPOSIT = 0n      // Pas de deposit extra pour atoms
const MIN_TRIPLE_DEPOSIT = 10000000000000000n   // 0.01 TRUST (1e16 wei)
const VOTE_STAKE = 1000000000000000000n         // 1 TRUST (1e18 wei)

// Gas config
const BLOCKCHAIN_CONFIG = {
  DEFAULT_GAS: 2000000n,
  MAX_FEE_PER_GAS: 1000000000n,        // 1 gwei
  MAX_PRIORITY_FEE_PER_GAS: 100000000n, // 0.1 gwei
  BATCH_SIZE: 20,
  RETRY_ATTEMPTS: 3
}
```

**Piege courant** : les votes utilisent `curveId = 1n` (linear), PAS `2n` (progressive). C'est voulu, pas un bug.

## 6. Address Handling

### Quatre contextes, quatre formats

| Contexte | Format | Methode |
|----------|--------|---------|
| Chrome storage keys | lowercase | `walletAddress.toLowerCase()` |
| On-chain operations | EIP-55 checksum | `getAddress(walletAddress)` |
| Comparaisons | lowercase both sides | `a?.toLowerCase() === b?.toLowerCase()` |
| GraphQL queries | `_ilike` (case-insensitive) | `{ account_id: { _ilike: $address } }` |

```typescript
import { getAddress } from "viem"

// Storage : TOUJOURS lowercase
const key = getWalletKey("discovery_gold", walletAddress.toLowerCase())

// On-chain : TOUJOURS checksum
const checksumAddress = getAddress(walletAddress)

// Comparaison : TOUJOURS lowercase les deux
if (walletA?.toLowerCase() === walletB?.toLowerCase()) { ... }
```

## 7. Proxy Approval (one-time)

Avant la premiere transaction, le user doit approuver le proxy Sofia :

```typescript
// lib/services/AtomService.ts
async ensureProxyApproval(address: string): Promise<void> {
  // 1. Verifier le cache chrome.storage
  const storageKey = `proxy_approved_${address.toLowerCase()}`
  const stored = await chrome.storage.local.get(storageKey)
  if (stored[storageKey]) return  // Deja approuve

  // 2. Demander l'approbation
  const txHash = await BlockchainService.requestProxyApproval()
  const confirmed = await BlockchainService.waitForApprovalConfirmation(txHash)

  if (!confirmed) throw new Error("Proxy approval transaction failed")

  // 3. Cacher le resultat
  await chrome.storage.local.set({ [storageKey]: true })
}
```

**Appele par** : `AtomService` et `TripleService` avant toute creation/deposit.

## 8. Transaction Error Handling

### Categories d'erreurs

```typescript
catch (error) {
  const msg = error instanceof Error ? error.message : "Unknown error"

  // User a rejete la transaction (popup wallet)
  if (msg.includes("rejected") || msg.includes("denied")) {
    throw new Error("Transaction rejected by user")
  }

  // Insufficient balance
  if (msg.includes("insufficient") || msg.includes("balance")) {
    throw new Error("Insufficient TRUST balance")
  }

  // Revert on-chain
  if (msg.includes("revert") || msg.includes("execution reverted")) {
    throw new Error(`Contract reverted: ${msg}`)
  }

  // Transaction minee mais echouee
  // Detecte par receipt.status !== "success"
  if (msg.includes("Transaction failed")) {
    throw new Error(msg)
  }

  throw error
}
```

### Dans les hooks (UI feedback)

```typescript
const [error, setError] = useState<string | null>(null)
const [isProcessing, setIsProcessing] = useState(false)

const doTransaction = useCallback(async () => {
  setIsProcessing(true)
  setError(null)
  try {
    await myService.writeOnChain(...)
    // Success: update UI, show toast
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Unknown error"
    setError(msg)  // Affiche dans la modal
  } finally {
    setIsProcessing(false)
  }
}, [])
```

## 9. Batch Transaction Pattern

Pour creer plusieurs atoms/triples en une seule transaction :

```typescript
// lib/services/AtomService.ts — createAtomsFromPinned()

// 1. Verifier lesquels existent deja (en parallele)
const atomChecks = await Promise.all(
  pinnedAtoms.map(async (pinned) => {
    const check = await BlockchainService.checkAtomExists(pinned.ipfsUri)
    return { ...pinned, exists: check.exists, atomHash: check.atomHash }
  })
)

// 2. Separer existants et nouveaux
const existing = atomChecks.filter(a => a.exists)   // → resultats immediats
const toCreate = atomChecks.filter(a => !a.exists)   // → une seule tx

// 3. Creer tous les nouveaux en UNE transaction
if (toCreate.length > 0) {
  const encodedDataArray = toCreate.map(a => a.encodedData)
  const depositsArray = toCreate.map(() => MIN_ATOM_DEPOSIT)
  const multiVaultCost = atomCost * BigInt(toCreate.length)
  const totalCost = await BlockchainService.getTotalCreationCost(0, 0n, multiVaultCost)

  // Simulate → Execute → Wait
  await publicClient.simulateContract({ ... })
  const hash = await walletClient.writeContract({ ... })
  await publicClient.waitForTransactionReceipt({ hash })
}
```

**Avantage** : le user signe UNE seule fois au lieu de N fois.

## 10. Wallet Connection Flow

```
Extension UI → Privy Auth Page (external tab)
    ↓ User authenticates
Privy Auth Page → chrome.runtime.sendMessage (external)
    ↓ type: "WALLET_CONNECTED", data: { walletAddress, walletType }
Background (messageHandlers.ts) → validate origin
    ↓ store in chrome.storage.session + local
    ↓ clear IndexedDB if wallet changed
    ↓ initializeOnWalletConnect()
Side Panel → useWalletFromStorage() → chrome.storage.onChanged listener
    ↓ UI updates reactively
```

### EIP-6963 Provider Discovery

```typescript
// contents/walletBridge.ts (world: "MAIN")
import { createStore } from "mipd"

const providerStore = createStore()  // Decouvre tous les wallets injectes
providerStore.subscribe((providers) => {
  // MetaMask, Rabby, Coinbase Wallet, etc.
})

// Selection par nom (stocke dans chrome.storage.session)
selectProviderByName(walletType)
```

### Methodes RPC whitelistees

```typescript
const ALLOWED_RPC_METHODS = [
  "eth_requestAccounts", "eth_accounts",
  "eth_chainId", "wallet_switchEthereumChain",
  "eth_call", "eth_estimateGas", "eth_getBalance",
  "eth_sendTransaction", "personal_sign",
  "eth_signTypedData_v4",
  "wallet_sendCalls"
]
```

Toute methode non listee est refusee avec `code: -32601`.

## 11. Chain Configuration

```typescript
// lib/config/chainConfig.dev.ts (testnet)
export const intuitionTestnet = defineChain({
  id: 13579,
  name: "Intuition Testnet",
  nativeCurrency: { decimals: 18, name: "Trust", symbol: "TRUST" },
  rpcUrls: {
    default: { http: ["https://testnet.rpc.intuition.systems"] }
  }
})

// Selection automatique par env
const network = process.env.PLASMO_PUBLIC_NETWORK || "testnet"
// → "testnet" (dev), "mainnet" (prod), "local" (hardhat)
```

| Parametre | Testnet | Mainnet |
|-----------|---------|---------|
| Chain ID | 13579 | 1155 |
| RPC | testnet.rpc.intuition.systems | rpc.intuition.systems |
| GraphQL | testnet.intuition.sh/v1/graphql | mainnet.intuition.sh/v1/graphql |

## 12. Anti-patterns

- **NE PAS** utiliser les hooks Wagmi (`useAccount`, `useWriteContract`) — utiliser `getClients()` directement
- **NE PAS** hardcoder des adresses de contrat — utiliser `BlockchainService.getContractAddress()`
- **NE PAS** oublier `simulateContract` avant `writeContract` — detecte les reverts gratuitement
- **NE PAS** comparer des adresses avec `===` — toujours `.toLowerCase()` les deux
- **NE PAS** confondre `curveId = 1n` (creation/vote) et `curveId = 2n` (deposit regulier)
- **NE PAS** utiliser `formatEther/parseEther` pour afficher des montants TRUST — utiliser `formatBalance` de `~/lib/utils`
- **NE PAS** oublier `maxFeePerGas` et `maxPriorityFeePerGas` dans `writeContract`
