---
name: testing
description: Setup vitest et patterns de tests pour Sofia. Mock Chrome APIs, services singleton, hooks React, utilitaires purs, et GraphQL client. Utilise cette skill pour ecrire des tests ou mettre en place l'infrastructure de test.
allowed-tools: Read, Write, Edit, Bash, Grep, Glob
argument-hint: [fichier-ou-pattern-a-tester]
disable-model-invocation: true
context: fork
agent: general-purpose
---

# Testing Sofia — Vitest Patterns

Tu es un expert testing pour extensions Chrome avec Vitest. Tu connais les patterns Sofia et sais mocker les APIs Chrome, les services singleton, et le GraphQL client.

## Etat actuel

- **Vitest** existe dans `extension/packages/graphql/vitest.config.ts` (1 test existant)
- **Pas de vitest** dans `extension/` (le package principal)
- **Pas de React Testing Library** installe
- **Scripts manuels** dans `extension/background/__test__/` (tsx, pas vitest)

## Setup Vitest pour `extension/`

Si vitest n'est pas configure dans `extension/`, le mettre en place :

### 1. Installer les dependances

```bash
cd extension && pnpm add -D vitest @testing-library/react @testing-library/jest-dom jsdom
```

### 2. Creer `extension/vitest.config.ts`

```typescript
import { defineConfig } from "vitest/config"
import path from "path"

export default defineConfig({
  test: {
    environment: "jsdom",
    globals: true,
    setupFiles: ["./vitest.setup.ts"],
    include: ["**/*.test.ts", "**/*.test.tsx"],
    exclude: ["node_modules", "build", "packages/**"],
    coverage: {
      provider: "v8",
      include: ["lib/utils/**", "lib/services/**", "hooks/**"]
    }
  },
  resolve: {
    alias: {
      "~": path.resolve(__dirname, ".")
    }
  }
})
```

### 3. Creer `extension/vitest.setup.ts`

```typescript
import { vi } from "vitest"

// Mock chrome.* APIs globalement
const mockStorage = {
  local: {
    get: vi.fn().mockResolvedValue({}),
    set: vi.fn().mockResolvedValue(undefined),
    remove: vi.fn().mockResolvedValue(undefined)
  },
  session: {
    get: vi.fn().mockResolvedValue({}),
    set: vi.fn().mockResolvedValue(undefined),
    remove: vi.fn().mockResolvedValue(undefined)
  },
  onChanged: {
    addListener: vi.fn(),
    removeListener: vi.fn()
  }
}

const mockRuntime = {
  sendMessage: vi.fn().mockResolvedValue({ success: true }),
  onMessage: {
    addListener: vi.fn(),
    removeListener: vi.fn()
  },
  onMessageExternal: {
    addListener: vi.fn(),
    removeListener: vi.fn()
  },
  lastError: null
}

const mockTabs = {
  query: vi.fn().mockResolvedValue([]),
  create: vi.fn().mockResolvedValue({}),
  update: vi.fn().mockResolvedValue({}),
  sendMessage: vi.fn().mockResolvedValue({})
}

const mockAction = {
  setBadgeText: vi.fn().mockResolvedValue(undefined),
  setBadgeBackgroundColor: vi.fn().mockResolvedValue(undefined)
}

globalThis.chrome = {
  storage: mockStorage,
  runtime: mockRuntime,
  tabs: mockTabs,
  action: mockAction,
  sidePanel: { open: vi.fn() },
  alarms: {
    create: vi.fn(),
    clear: vi.fn(),
    onAlarm: { addListener: vi.fn() }
  }
} as any

// Helper pour reinitialiser tous les mocks
export function resetChromeMocks() {
  vi.clearAllMocks()
}
```

### 4. Ajouter le script dans `extension/package.json`

```json
"scripts": {
  "test": "vitest run",
  "test:watch": "vitest",
  "test:coverage": "vitest run --coverage"
}
```

## Categories de tests

### Categorie 1 — Utilitaires purs (facile, pas de mock)

Fichiers cibles : `lib/utils/*.ts`

Ce sont des fonctions pures sans effet de bord. Tester en priorite.

```typescript
// lib/utils/__tests__/levelCalculation.test.ts
import { describe, it, expect } from "vitest"
import { calculateLevel, calculateLevelProgress, LEVEL_THRESHOLDS } from "../levelCalculation"

describe("calculateLevel", () => {
  it("retourne level 1 pour 0 certifications", () => {
    expect(calculateLevel(0)).toBe(1)
  })

  it("retourne level 2 pour 3 certifications (seuil exact)", () => {
    expect(calculateLevel(3)).toBe(2)
  })

  it("retourne level 2 pour 5 certifications (entre seuils)", () => {
    expect(calculateLevel(5)).toBe(2)
  })

  it("retourne le level max pour beaucoup de certifications", () => {
    expect(calculateLevel(100)).toBe(LEVEL_THRESHOLDS.length)
  })
})

describe("calculateLevelProgress", () => {
  it("retourne 0% au debut d'un level", () => {
    const result = calculateLevelProgress(3)  // Debut level 2
    expect(result.progressPercent).toBe(0)
  })

  it("retourne 100% max", () => {
    const result = calculateLevelProgress(7)  // Debut level 3
    expect(result.progressPercent).toBeLessThanOrEqual(100)
  })

  it("calcule xpToNextLevel correctement", () => {
    const result = calculateLevelProgress(5)
    expect(result.xpToNextLevel).toBe(7 - 5)  // Seuil level 3 = 7
  })
})
```

**Autres fichiers a tester en priorite :**

| Fichier | Fonctions | Cas de test |
|---------|-----------|-------------|
| `domainUtils.ts` | `normalizeDomain`, `extractDomain`, `shouldExcludeDomain` | Subdomains, URLs malformees, null |
| `streakUtils.ts` | `calculateStreaks`, `toDateStr` | Streak actif, casse, vide |
| `formatters.ts` | `formatDuration`, `formatBalance`, `getFaviconUrl` | Edge cases (0, BigInt, URL invalide) |
| `certificationHelpers.ts` | `intentionToCertification`, `calculateDominantCertification`, `sumCertifications` | Mappings, objets vides |
| `storageKeyUtils.ts` | `getWalletKey` | Concatenation, lowercase |
| `cleanTitle.ts` | `cleanTitle`, `getDisplayTitle` | Suffixes site, hash routes |
| `normalizeUrl.ts` | `normalizeUrl` | Params tracking, protocoles |

### Categorie 2 — Services avec chrome.storage (moyen)

Pattern : mocker `chrome.storage.local.get/set`, tester la logique metier.

```typescript
// lib/services/__tests__/GoldService.test.ts
import { describe, it, expect, vi, beforeEach } from "vitest"
import { resetChromeMocks } from "../../vitest.setup"

// Importer APRES le setup des mocks chrome
import { GoldServiceClass } from "../GoldService"

describe("GoldService", () => {
  let goldService: GoldServiceClass

  beforeEach(() => {
    resetChromeMocks()
    goldService = new GoldServiceClass()
  })

  describe("getGoldState", () => {
    it("retourne 0 pour un wallet sans donnees", async () => {
      vi.mocked(chrome.storage.local.get).mockResolvedValue({})

      const state = await goldService.getGoldState("0xabc")
      expect(state.totalGold).toBe(0)
      expect(state.discoveryGold).toBe(0)
    })

    it("calcule totalGold = discovery + certification - spent", async () => {
      vi.mocked(chrome.storage.local.get).mockResolvedValue({
        "discovery_gold_0xabc": 50,
        "certification_gold_0xabc": 30,
        "spent_gold_0xabc": 20
      })

      const state = await goldService.getGoldState("0xABC")  // Test lowercase
      expect(state.totalGold).toBe(60)  // 50 + 30 - 20
    })
  })

  describe("spendGold", () => {
    it("refuse si pas assez de gold", async () => {
      vi.mocked(chrome.storage.local.get).mockResolvedValue({
        "discovery_gold_0xabc": 10,
        "certification_gold_0xabc": 0,
        "spent_gold_0xabc": 0
      })

      const result = await goldService.spendGold("0xABC", 50)
      expect(result.success).toBe(false)
      expect(result.error).toBeDefined()
    })

    it("incremente spent_gold en cas de succes", async () => {
      vi.mocked(chrome.storage.local.get).mockResolvedValue({
        "discovery_gold_0xabc": 100,
        "certification_gold_0xabc": 0,
        "spent_gold_0xabc": 0
      })

      const result = await goldService.spendGold("0xABC", 30)
      expect(result.success).toBe(true)
      expect(chrome.storage.local.set).toHaveBeenCalledWith(
        expect.objectContaining({ "spent_gold_0xabc": 30 })
      )
    })
  })

  describe("addCertificationGold", () => {
    it("ajoute 10 gold par defaut", async () => {
      vi.mocked(chrome.storage.local.get).mockResolvedValue({})

      await goldService.addCertificationGold("0xABC")
      expect(chrome.storage.local.set).toHaveBeenCalledWith(
        expect.objectContaining({ "certification_gold_0xabc": 10 })
      )
    })
  })
})
```

### Categorie 3 — Services avec useSyncExternalStore (avance)

Pattern : tester subscribe/getSnapshot, notifications de listeners, guard in-flight.

```typescript
// lib/services/__tests__/DiscoveryScoreService.test.ts
import { describe, it, expect, vi, beforeEach } from "vitest"
import { resetChromeMocks } from "../../vitest.setup"

describe("DiscoveryScoreService", () => {
  let service: any

  beforeEach(async () => {
    resetChromeMocks()
    // Re-importer pour reset le singleton
    vi.resetModules()
    const mod = await import("../DiscoveryScoreService")
    service = new mod.DiscoveryScoreServiceClass()
  })

  it("getSnapshot retourne l'etat initial", () => {
    const state = service.getSnapshot()
    expect(state.loading).toBe(false)
    expect(state.stats).toBeNull()
  })

  it("subscribe enregistre un listener et retourne un unsubscribe", () => {
    const listener = vi.fn()
    const unsubscribe = service.subscribe(listener)

    expect(typeof unsubscribe).toBe("function")
    unsubscribe()
  })

  it("notifie les listeners apres updateState", () => {
    const listener = vi.fn()
    service.subscribe(listener)

    // Simuler un update interne
    service["updateState"]({ loading: true })

    expect(listener).toHaveBeenCalled()
    expect(service.getSnapshot().loading).toBe(true)
  })

  it("guard in-flight empeche les fetches concurrents", async () => {
    service["fetchInFlight"] = true

    // Le fetch devrait etre skip
    await service["fetchDiscoveryScore"]("0xabc")

    // Pas d'appel GraphQL car fetchInFlight = true
    expect(service.getSnapshot().loading).toBe(false)
  })
})
```

### Categorie 4 — Hooks React (necessite React Testing Library)

```typescript
// hooks/__tests__/useGoldSystem.test.tsx
import { describe, it, expect, vi, beforeEach } from "vitest"
import { renderHook, act } from "@testing-library/react"
import { resetChromeMocks } from "../../vitest.setup"

// Mock useWalletFromStorage
vi.mock("~/hooks/useWalletFromStorage", () => ({
  useWalletFromStorage: () => ({
    walletAddress: "0xTestWallet",
    authenticated: true,
    isLoading: false,
    ready: true
  })
}))

describe("useGoldSystem", () => {
  beforeEach(() => {
    resetChromeMocks()
    vi.resetModules()
  })

  it("charge le gold depuis chrome.storage au mount", async () => {
    vi.mocked(chrome.storage.local.get).mockResolvedValue({
      "discovery_gold_0xtestwallet": 50,
      "certification_gold_0xtestwallet": 20,
      "spent_gold_0xtestwallet": 10
    })

    const { useGoldSystem } = await import("../useGoldSystem")
    const { result } = renderHook(() => useGoldSystem())

    // Attendre le chargement async
    await vi.waitFor(() => {
      expect(result.current.loading).toBe(false)
    })

    expect(result.current.totalGold).toBe(60)
    expect(result.current.discoveryGold).toBe(50)
  })

  it("reagit aux changements de chrome.storage", async () => {
    vi.mocked(chrome.storage.local.get).mockResolvedValue({})

    const { useGoldSystem } = await import("../useGoldSystem")
    const { result } = renderHook(() => useGoldSystem())

    // Simuler un changement storage
    const storageListener = vi.mocked(chrome.storage.onChanged.addListener)
      .mock.calls[0]?.[0]

    if (storageListener) {
      act(() => {
        storageListener({
          "discovery_gold_0xtestwallet": { newValue: 100 }
        }, "local")
      })
    }

    expect(result.current.discoveryGold).toBe(100)
  })
})
```

### Categorie 5 — GraphQL client mock

```typescript
// Mocker le client GraphQL
vi.mock("~/lib/clients/graphql-client", () => ({
  intuitionGraphqlClient: {
    request: vi.fn(),
    fetchAllPages: vi.fn().mockResolvedValue([]),
    clearCache: vi.fn()
  }
}))

// Usage dans un test
import { intuitionGraphqlClient } from "~/lib/clients/graphql-client"

it("fetch les triples depuis GraphQL", async () => {
  vi.mocked(intuitionGraphqlClient.fetchAllPages).mockResolvedValue([
    { term_id: "0x1", subject: { label: "I" }, predicate: { label: "visits for work" }, object: { label: "github.com" } }
  ])

  const result = await myService.fetchTriples("0xabc")
  expect(result).toHaveLength(1)
  expect(intuitionGraphqlClient.fetchAllPages).toHaveBeenCalledWith(
    expect.anything(),
    expect.objectContaining({ userAddress: expect.stringContaining("0xabc") }),
    "triples",
    100,
    100
  )
})
```

## Pipeline de test

Quand `$ARGUMENTS` est fourni (fichier ou pattern a tester) :

### Phase 1 — Analyse

1. Lire le fichier source pour comprendre les fonctions/methodes
2. Identifier la categorie (util pur, service chrome, service reactive, hook)
3. Lister les cas de test necessaires (happy path, edge cases, erreurs)

### Phase 2 — Generation

1. Creer le fichier test a cote du source (`__tests__/NomFichier.test.ts`)
2. Importer les dependances et configurer les mocks selon la categorie
3. Ecrire les tests en suivant les patterns ci-dessus
4. Chaque `describe` = une fonction/methode
5. Chaque `it` = un cas precis et nomme clairement

### Phase 3 — Execution

```bash
cd /home/chauche/Sofia/extension && pnpm vitest run <chemin-du-test>
```

Si le test echoue, corriger et re-executer.

## Regles de test

### Nommage
- Fichier : `NomFichier.test.ts` (ou `.test.tsx` pour les hooks React)
- Location : `__tests__/` a cote du source
- `describe` : nom de la fonction/classe
- `it` : phrase descriptive en francais ou anglais

### Structure AAA (Arrange-Act-Assert)
```typescript
it("description du cas", async () => {
  // Arrange
  vi.mocked(chrome.storage.local.get).mockResolvedValue({ key: "value" })

  // Act
  const result = await myService.doThing("input")

  // Assert
  expect(result).toEqual(expected)
  expect(chrome.storage.local.set).toHaveBeenCalledWith(expect.objectContaining({ ... }))
})
```

### Isolation
- `beforeEach(() => resetChromeMocks())` dans chaque `describe`
- `vi.resetModules()` si le module a un etat singleton
- Ne jamais dependre de l'ordre d'execution des tests
- Chaque test cree sa propre instance si necessaire

### Ce qu'on ne teste PAS
- Les ABIs (generes)
- Les types TypeScript (verification a la compilation)
- Les fichiers CSS
- Les configs Plasmo
- Le code genere par GraphQL codegen

## Mocks avances

### Mock IndexedDB

```typescript
import { vi } from "vitest"

vi.mock("~/lib/database", () => ({
  sofiaDB: {
    init: vi.fn().mockResolvedValue(undefined),
    get: vi.fn().mockResolvedValue(null),
    put: vi.fn().mockResolvedValue(undefined),
    getAll: vi.fn().mockResolvedValue([]),
    delete: vi.fn().mockResolvedValue(undefined),
    clear: vi.fn().mockResolvedValue(undefined),
    getByIndex: vi.fn().mockResolvedValue(null),
    getAllByIndex: vi.fn().mockResolvedValue([])
  },
  STORES: {
    TRIPLETS_DATA: "TRIPLETS_DATA",
    NAVIGATION_DATA: "NAVIGATION_DATA",
    INTENTION_GROUPS: "INTENTION_GROUPS",
    // ... tous les stores
  },
  IntentionGroupsService: {
    getAllGroups: vi.fn().mockResolvedValue([]),
    getGroup: vi.fn().mockResolvedValue(null),
    saveGroup: vi.fn().mockResolvedValue(undefined),
    deleteGroup: vi.fn().mockResolvedValue(undefined),
    clearAll: vi.fn().mockResolvedValue(undefined)
  }
}))
```

### Mock viem

```typescript
vi.mock("viem", () => ({
  createPublicClient: vi.fn().mockReturnValue({
    readContract: vi.fn(),
    simulateContract: vi.fn(),
    waitForTransactionReceipt: vi.fn().mockResolvedValue({ status: "success" })
  }),
  createWalletClient: vi.fn().mockReturnValue({
    writeContract: vi.fn().mockResolvedValue("0xhash"),
    getChainId: vi.fn().mockResolvedValue(13579)
  }),
  getAddress: vi.fn((addr: string) => addr),
  formatUnits: vi.fn((v: bigint, d: number) => (Number(v) / 10 ** d).toString()),
  parseUnits: vi.fn((v: string, d: number) => BigInt(Math.floor(Number(v) * 10 ** d))),
  http: vi.fn(),
  custom: vi.fn(),
  defineChain: vi.fn()
}))
```

### Mock fetch (pour Mastra API)

```typescript
const mockFetch = vi.fn()
globalThis.fetch = mockFetch

mockFetch.mockResolvedValue({
  ok: true,
  json: async () => ({
    text: JSON.stringify({ category: "work", confidence: 0.9 })
  })
})
```

## Priorite de test

| Priorite | Categorie | Fichiers | Effort |
|----------|-----------|----------|--------|
| 1 | Utils purs | `levelCalculation`, `streakUtils`, `domainUtils`, `formatters`, `certificationHelpers` | Faible |
| 2 | storageKeyUtils + logger | `storageKeyUtils`, `logger` | Faible |
| 3 | Services chrome.storage | `GoldService`, `XPService`, `QuestTrackingService` | Moyen |
| 4 | Services singleton | `GroupManager`, `SessionTracker` | Moyen |
| 5 | Hooks simples | `useGoldSystem`, `useLevelUp` | Eleve |
| 6 | GraphQL client | `graphql-client.ts` (cache, retry, pagination) | Eleve |
