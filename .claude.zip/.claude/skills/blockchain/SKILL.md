---
name: blockchain
description: Reference des patterns blockchain Intuition pour Sofia. Triples, atoms, vaults, fee proxy, bonding curves, transaction flows, et address handling. Consulte cette skill quand tu travailles avec des interactions on-chain.
allowed-tools: Read, Grep, Glob
---

# Blockchain / Intuition — Sofia

Tu es un expert des interactions blockchain du projet Sofia avec le protocole Intuition.

## Concepts fondamentaux

### Atom
Entite de base on-chain (URL, compte, concept). Cree via IPFS pin + MultiVault.

```typescript
// Creation d'atom
atomService.createAtomOnChain(label, walletAddress)
// 1. Pin sur IPFS → obtenir URI
// 2. Hex-encode l'URI
// 3. SofiaFeeProxy.createAtoms([hexData])
```

### Triple
Relation subject-predicate-object entre 3 atoms.

```
[Subject Atom] —— [Predicate Atom] ——> [Object Atom]
  "I"              "visits for work"     "github.com"
```

### Vault
Chaque atom et triple a un vault avec une bonding curve. Les utilisateurs deposent des TRUST tokens.

### term_id
Identifiant unique d'un atom (bytes32 hash). **JAMAIS `id`** — le type `atoms` n'a PAS de champ `id`.

### wallet_id
L'adresse du vault de l'atom (PAS l'adresse de l'utilisateur).
Pour obtenir l'adresse wallet d'un utilisateur depuis un account atom : `atom.value.account.id`

## Contrats

### Sofia Fee Proxy
Toutes les transactions passent par le proxy qui collecte des fees :

```
User Transaction → Sofia Fee Proxy → Intuition MultiVault
```

- **Testnet** : `0x26F81d723Ad1648194FAA4b7E235105Fd1212c6c`
- **MultiVault** : `0x6E35cF57A41fA15eA0EaE9C33e751b01A784Fe7e`
- ABI : `extension/ABI/SofiaFeeProxyAbi.ts`

### Operations du proxy

| Operation | Methode | Usage |
|-----------|---------|-------|
| Creer atoms | `createAtoms(bytes[])` | URLs, intentions |
| Creer triples | `createTriples(uint256[][3])` | Certifications |
| Deposer | `deposit(address receiver, uint256 vaultId)` | Vote, stake |
| Retirer | `redeem(uint256 shares, address receiver, uint256 vaultId)` | Unstake |

## Bonding Curves

| curveId | Type | Usage |
|---------|------|-------|
| `1n` | **Lineaire** | Creation d'atoms/triples ET vote deposits |
| `2n` | **Progressive** | Deposits reguliers sur triples existants |

**ATTENTION :** Les vote deposits utilisent `curveId = 1n` (PAS `2n`). C'est intentionnel, PAS un bug.

## Transaction Flow

```typescript
// Toujours dans cet ordre :
// 1. SIMULATION (dry run, pas de gas)
const { request } = await publicClient.simulateContract({
  address: SOFIA_FEE_PROXY,
  abi: SofiaFeeProxyAbi,
  functionName: "createTriples",
  args: [subjectIds, predicateIds, objectIds],
  value: totalCost,
  account: walletAddress
})

// 2. EXECUTION (transaction reelle)
const hash = await walletClient.writeContract(request)

// 3. CONFIRMATION (attendre inclusion dans un bloc)
const receipt = await publicClient.waitForTransactionReceipt({ hash })

// 4. INDEXER DELAY (attendre 3s pour que l'indexer traite)
await new Promise(resolve => setTimeout(resolve, 3000))

// 5. REFRESH (vider le cache GraphQL + refetch)
intuitionGraphqlClient.clearCache()
await refetch()
```

## Fee Calculation

```typescript
// Calculer le cout total avant une transaction
const { totalCost, protocolFee, sofiaFee } =
  await BlockchainService.calculateDepositFee(depositAmount)

// totalCost = depositAmount + protocolFee + sofiaFee
// Passer totalCost comme `value` dans la transaction
```

## Certification Flow (I | visits_for_X | URL)

```typescript
// 1. Resoudre le predicate ID
const predicateId = await tripleService.getPredicateIdIfExists(predicateLabel)
// ou creer l'atom si necessaire

// 2. Resoudre l'object ID (URL)
const objectId = await atomService.getOrCreateAtom(url, walletAddress)

// 3. Creer le triple
await tripleService.createTripleOnChain(
  subjectId: SUBJECT_IDS.I,  // 0n = "I" (l'utilisateur connecte)
  predicateId,
  objectId,
  walletAddress
)
```

**Gestion triple existant :**
```typescript
// Si le triple existe deja → DEPOSIT au lieu de CREATE
if (await BlockchainService.checkTripleExists(subjectId, predicateId, objectId)) {
  // Deposit avec curveId = 2n (progressive)
  await tripleService.depositOnTriple(vaultId, amount, walletAddress)
} else {
  // Create avec curveId = 1n (lineaire)
  await tripleService.createTripleOnChain(...)
}
```

## Vote Flow (I | like/dislike | tripleTermId)

Pattern de triple imbrique — l'object est un AUTRE triple :

```typescript
tripleService.createTripleOnChain(
  subject: SUBJECT_IDS.I,
  predicate: likePredicateId,    // "like" ou "dislike"
  object: tripleTermId,          // ← le term_id d'un triple existant
  address,
  VOTE_STAKE,                    // 1 TRUST
  curveId: 1n                    // Lineaire pour les votes (intentionnel)
)
```

## Address Handling

```typescript
// Storage keys : TOUJOURS lowercase
const key = getWalletKey("discovery_gold", walletAddress.toLowerCase())

// On-chain : TOUJOURS checksummed (viem)
import { getAddress } from "viem"
const checksumAddress = getAddress(walletAddress)

// Comparaisons : TOUJOURS lowercase des deux cotes
if (walletA?.toLowerCase() === walletB?.toLowerCase()) { ... }

// GraphQL : TOUJOURS _ilike (case-insensitive)
{ account_id: { _ilike: $address } }
```

## Proxy Approval

Avant le premier deposit, l'utilisateur doit approuver le proxy :

```typescript
// Verification (une seule fois par wallet)
const isApproved = await BlockchainService.checkProxyApproval(walletAddress)

if (!isApproved) {
  // Demander l'approbation via transaction
  await tripleService.ensureProxyApproval(walletAddress)
  // Sauvegarder en storage pour eviter de re-verifier
  await chrome.storage.local.set({
    [getWalletKey("proxy_approved", wallet)]: true
  })
}
```

## Reseaux

| Param | Testnet (`pnpm dev`) | Mainnet (`pnpm build`) |
|-------|---------------------|----------------------|
| Chain ID | 13579 | 1155 |
| Currency | TRUST | TRUST |
| RPC | testnet.rpc.intuition.systems | rpc.intuition.systems |
| Explorer | testnet.explorer.intuition.systems | explorer.intuition.systems |
| GraphQL | testnet.intuition.sh/v1/graphql | mainnet.intuition.sh/v1/graphql |

Config dans `lib/config/chainConfig.dev.ts` / `chainConfig.prod.ts`.

## Error Handling Blockchain

```typescript
try {
  const result = await tripleService.createTripleOnChain(...)
} catch (error) {
  const msg = error instanceof Error ? error.message : "Unknown error"

  // Erreurs connues a gerer gracieusement :
  if (msg.includes("MultiVault_TripleExists")) {
    // Triple deja cree → traiter comme succes, faire un deposit
  }
  if (msg.includes("MultiVault_AtomExists")) {
    // Atom deja cree → recuperer l'ID existant
  }
  if (msg.includes("User rejected")) {
    // Utilisateur a refuse dans le wallet → annuler silencieusement
  }
  if (msg.includes("insufficient funds")) {
    // Pas assez de TRUST → afficher message d'erreur
  }
}
```

## Services blockchain

| Service | Methodes cles |
|---------|--------------|
| `atomService` | `createAtomOnChain()`, `batchCreateAtoms()`, `getOrCreateAtom()` |
| `tripleService` | `createTripleOnChain()`, `depositOnTriple()`, `getPredicateIdIfExists()`, `ensureProxyApproval()` |
| `BlockchainService` (static) | `calculateDepositFee()`, `checkTripleExists()`, `checkAtomExists()`, `checkProxyApproval()` |

## Subject IDs speciaux

```typescript
const SUBJECT_IDS = {
  I: 0n,  // Represente l'utilisateur connecte (convention Intuition)
}
```

`0n` comme subjectId signifie "moi" — le MultiVault remplace par l'adresse du caller.
