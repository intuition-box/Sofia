---
name: refactor
description: Refactoring suivant les patterns Sofia. Extraction de services, deduplication d'utilitaires, amincissement de hooks, nettoyage de barrels. Respecte l'architecture en couches et les conventions du projet.
allowed-tools: Read, Write, Edit, Bash, Grep, Glob
argument-hint: [cible: fichier, hook, service, ou description]
disable-model-invocation: true
context: fork
agent: general-purpose
---

# Refactoring — Sofia

Tu es un expert du refactoring pour le projet Sofia. Tu connais l'architecture en couches et les patterns de service extraction qui ont ete appliques dans les commits recents.

Cible du refactoring : **$ARGUMENTS**

## Phase 1 — Analyse

Avant de toucher au code :

1. **Lis le fichier cible** et identifie les problemes
2. **Mesure** : nombre de lignes, responsabilites, imports
3. **Classifie** le type de refactoring necessaire (voir ci-dessous)
4. **Presente le plan** a l'utilisateur

## Types de refactoring

### A. Extraction de service (Hook → Service)

Quand un hook contient de la logique metier (> 100 lignes, appels API, calculs complexes) :

```
AVANT : useMonFeature.ts (300 lignes, logique + state + UI)

APRES :
  lib/services/MonFeatureService.ts  (logique metier extraite)
  hooks/useMonFeature.ts             (thin wrapper ~50 lignes)
```

**Etapes :**
1. Identifier la logique metier dans le hook (tout ce qui n'est pas React state/effects)
2. Creer `lib/services/MonFeatureService.ts` avec la classe singleton
3. Deplacer la logique dans le service
4. Simplifier le hook pour qu'il delegue au service
5. Ajouter au barrel `lib/services/index.ts`
6. Verifier que le hook reste < 100 lignes

**Pattern service singleton :**
```typescript
import { createServiceLogger } from "../utils/logger"
const logger = createServiceLogger("MonFeatureService")

class MonFeatureServiceClass {
  // Logique extraite du hook
}

export const monFeatureService = new MonFeatureServiceClass()
export { MonFeatureServiceClass }
```

**Si le service a un etat partage reactif**, utilise `useSyncExternalStore` :
```typescript
class MonReactiveServiceClass {
  private state: MonState = { /* initial */ }
  private listeners = new Set<() => void>()

  getSnapshot = (): MonState => this.state
  subscribe = (listener: () => void): (() => void) => {
    this.listeners.add(listener)
    return () => this.listeners.delete(listener)
  }

  private updateState(partial: Partial<MonState>) {
    this.state = { ...this.state, ...partial }
    for (const listener of this.listeners) listener()
  }
}
```

### B. Extraction d'utilitaires (Hook/Service → Utils)

Quand des fonctions pures sont dans un hook ou service :

```
AVANT : useLeaderboard.ts contient calculateStreaks(), toDateStr()

APRES :
  lib/utils/streakUtils.ts   (fonctions pures extraites)
  hooks/useLeaderboard.ts    (importe depuis ~/lib/utils)
```

**Criteres pour extraire :**
- Fonction pure (pas de side effects, pas de state)
- Reutilisable potentiellement ailleurs
- Ne depend pas de React

**Etapes :**
1. Identifier les fonctions pures
2. Creer/ajouter dans `lib/utils/monUtil.ts`
3. Ajouter au barrel `lib/utils/index.ts`
4. Remplacer l'ancien code par l'import du barrel

### C. Deduplication

Quand le meme code existe a plusieurs endroits :

```
AVANT :
  hooks/useA.ts      → getFaviconUrl() (reimplementation)
  hooks/useB.ts      → getFaviconUrl() (reimplementation)
  components/X.tsx   → getFaviconUrl() (reimplementation)

APRES :
  lib/utils/formatters.ts  → getFaviconUrl() (unique source)
  hooks/useA.ts            → import { getFaviconUrl } from "~/lib/utils"
```

**Etapes :**
1. Chercher toutes les reimplementations avec Grep
2. Choisir la meilleure implementation
3. La placer dans le bon fichier utils
4. Remplacer toutes les occurrences par l'import barrel
5. Supprimer le code duplique

### D. Nettoyage de barrel

Quand un barrel est incomplet ou desynchronise :

1. Lister tous les fichiers du dossier
2. Verifier que chaque export est dans le barrel
3. Supprimer les exports de fichiers supprimes
4. Trier les exports par ordre alphabetique

## Phase 2 — Implementation

Regles imperatives :

1. **Un commit logique par etape** — pas de mega-refactoring
2. **Pas de changement de comportement** — refactoring pur
3. **Barrel imports partout** — jamais d'imports directs apres refactoring
4. **Tester que le build passe** apres chaque etape (demander a l'utilisateur)
5. **Conserver les exports existants** — ne pas casser les imports existants
6. **Logger migration** — si le fichier change de couche, migrer le logger :
   - `createHookLogger` → `createServiceLogger` (hook → service)

## Phase 3 — Verification

Apres le refactoring :

- [ ] Le hook refactore est < 100 lignes (idealement < 80)
- [ ] Le service est un singleton exporte avec sa classe
- [ ] Les utils sont des fonctions pures sans side effects
- [ ] Tous les barrels sont a jour
- [ ] Aucun import direct (tout via barrels)
- [ ] Pas de code duplique restant
- [ ] Le comportement est identique (refactoring pur)
- [ ] Formatting Prettier respecte (no semi, double quotes)

## Metriques de succes

Rapport final :

```
## Refactoring: [cible]

### Avant
- Lignes total : X
- Fichiers impactes : X
- Code duplique : X occurrences

### Apres
- Lignes total : Y (delta: -Z)
- Nouveau service : MonFeatureService (Y lignes)
- Hook simplifie : useMonFeature (Y lignes, -Z%)
- Utils extraites : X fonctions

### Verification
- [ ] Build OK
- [ ] Barrels a jour
- [ ] Pas de regression
- [ ] quality-checker : PASS
```

## Phase 4 — Validation automatique

Apres le refactoring, lance l'agent **quality-checker** pour verifier que le code respecte toutes les conventions.
Si des issues BLOQUANTES sont detectees, corrige-les avant de presenter le resultat.
