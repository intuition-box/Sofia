# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

# Sofia — Claude Code Guide

## Project Overview

Sofia is a Chrome extension that tracks browsing activity, integrates with the Intuition blockchain protocol, and provides AI-driven recommendations. It consists of 3 independent packages (NOT a monorepo):

| Package | Description |
|---|---|
| `extension/` | Plasmo-based Chrome extension (Manifest V3), side panel UI |
| `sofia-mastra/` | AI backend — Mastra agents, workflows, GaiaNet LLM |
| `intuition-mcp-server/` | MCP server for Intuition knowledge graph access |

Each package has its own `node_modules`, `tsconfig`, and `package.json`. Use `pnpm` (10.15.1).

**Prerequisites:** Node.js >= 22.13.0, pnpm 10.15.1, Chrome browser.

**Testing & Linting:** No test framework (jest/vitest) is configured. No ESLint. Prettier is configured in `extension/.prettierrc.mjs` for formatting only. There are no CI/CD pipelines. The only validation is `pnpm dev` (Plasmo dev build) or `pnpm build` (Plasmo production build).

## Quick Start

```bash
# 1. Extension (main dev target)
cd extension && pnpm install && pnpm dev    # → Plasmo dev build (testnet)

# 2. AI backend (needed for chat, interest analysis, pulse)
cd sofia-mastra && pnpm install && pnpm dev # → http://localhost:4111

# 3. MCP server (needed for interest analysis only)
cd intuition-mcp-server && pnpm install && pnpm build && pnpm start:http  # → http://localhost:3001

# GraphQL codegen (after editing .graphql files)
cd extension/packages/graphql && pnpm codegen
```

Load the extension in Chrome: `chrome://extensions/` → Developer mode → Load unpacked → `extension/build/chrome-mv3-dev`

## Intuition Glossary

Sofia builds on the **Intuition protocol**. You must understand these concepts:

| Concept | Description | Example |
|---|---|---|
| **Atom** | A basic entity on-chain (URL, account, concept). Created via IPFS pin + MultiVault. | `"youtube.com"`, `"visits for work"`, user account |
| **Triple** | A subject-predicate-object relationship between atoms. `I | visits for work | youtube.com` | Certification, vote, follow |
| **Vault** | A staking vault attached to each atom/triple. Users deposit TRUST tokens (bonding curve). | Each triple has a vault where depositors earn shares |
| **term_id** | Unique identifier of an atom (bytes32 hash). Used to reference atoms in triples. | `0x7ab197b3...` |
| **vault_id** | Same as term_id in practice — the vault is identified by its atom/triple. | Used in `createTripleOnChain()` |
| **wallet_id** | The atom's own vault wallet address (NOT the user's wallet). | `atoms.wallet_id` field |
| **Predicate** | The "verb" atom in a triple. Sofia uses fixed predicates per environment. | `"visits for work"`, `"trusts"`, `"like"` |
| **Deposit** | Adding stake to an existing triple's vault (progressive bonding curve). | Voting deposits 1 TRUST |
| **Sofia Fee Proxy** | Smart contract that wraps MultiVault calls and collects Sofia fees. | All writes go through `SofiaFeeProxyAbi` |

**Key distinction:** `atoms.wallet_id` = atom's vault address. To get a **user's** wallet address from an account atom, use `atom.value.account.id` (joins to `accounts` table, EIP-55 checksummed).

## Extension Architecture

Layered architecture — respect the dependency direction:

```
React Components (extension/components/)
    ↓  Props only, no business logic
Custom Hooks (extension/hooks/)
    ↓  Orchestrate services, manage React state (thin wrappers)
Singleton Services (extension/lib/services/)
    ↓  ALL business logic, blockchain ops, external API calls
Pure Utilities (extension/lib/utils/)
    ↓  Stateless calculation functions, formatters, helpers
Config (extension/lib/config/)
    ↓  Chain config, predicate constants (single source of truth)
Infrastructure (extension/lib/database/, lib/clients/, Chrome APIs, Blockchain)
```

### Barrel File Imports (CRITICAL)

Always use barrel file imports. Never import from individual files:

```typescript
// CORRECT
import { goldService, groupManager, atomService } from "~/lib/services"
import { useFollowing, useQuestSystem } from "~/hooks"
import { normalizeUrl, createHookLogger, extractDomain } from "~/lib/utils"
import { CERTIFICATION_PREDICATE_LABELS } from "~/lib/config/predicateConstants"
import { sofiaDB } from "~/lib/database"
import type { IntentionGroupRecord } from "~/types/database"

// WRONG — never import from individual files
import { goldService } from "~/lib/services/GoldService"
import { createHookLogger } from "~/lib/utils/logger"
```

Available barrel files:
- `~/hooks` — 55 custom hooks
- `~/lib/services` — 19 singleton services
- `~/lib/database` — IndexedDB wrapper + 9 data services
- `~/lib/utils` — 50+ utility functions
- `~/types/*` — 22 type definition files (import from specific type files, e.g., `~/types/database`)

**Exception:** `~/lib/config/predicateConstants` and `~/lib/config/chainConfig` are imported directly (no barrel file for config).

### Path Alias

The `~` alias maps to `extension/` root (configured in tsconfig.json `paths: { "~*": ["./*"] }`).

### Singleton Services (19 services)

Services are classes instantiated once and exported as singletons:

```typescript
class GoldServiceClass { ... }
export const goldService = new GoldServiceClass()
```

| Service | Singleton | Role |
|---|---|---|
| `AtomService` | `atomService` | IPFS pinning + on-chain atom creation (single & batch) |
| `TripleService` | `tripleService` | On-chain triple creation/deposit (single & batch) |
| `BlockchainService` | (static) | Read-only blockchain ops: fee calculations, existence checks |
| `DiscoveryScoreService` | `discoveryScoreService` | Discovery ranking (Pioneer/Explorer/Contributor) + Gold sync |
| `UserCertificationsService` | `userCertificationsService` | Global certification cache (paginated GraphQL) |
| `MCPService` | `mcpService` | MCP session management + tool calls |
| `InterestAnalysisService` | `interestAnalysisService` | Interest caching, merging, AI analysis via Mastra |
| `GoldService` | `goldService` | Gold currency (discovery + certification - spent) |
| `XPService` | `xpService` | Quest XP (derived from claimed quests, read-only) |
| `LevelUpService` | `levelUpService` | Group level-up orchestration (Gold cost + AI predicate) |
| `GroupManager` | `groupManager` | Persistent intention groups (domain-based, IndexedDB) |
| `SessionTracker` | `sessionTracker` | URL visit buffering + flush to GroupManager |
| `MessageBus` | `messageBus` | Chrome runtime message sending (58 message types) |
| `PageDataService` | `pageDataService` | PAGE_DATA + PAGE_DURATION buffering and processing |
| `PulseService` | `pulseService` | Pulse analysis: collect tab data → PulseAgent |
| `BadgeService` | `badgeService` | Extension badge count (unpublished triplets) |
| `QuestTrackingService` | `questTrackingService` | Quest event tracking (streaks, votes, certifications) |
| `TripletStorageService` | `tripletStorageService` | Triplet storage in IndexedDB + badge update |
| `CurrencyMigrationService` | `currencyMigrationService` | One-time XP→Gold migration |

**Two services use `useSyncExternalStore` protocol** (React external store pattern):
- `discoveryScoreService` — auto-initializes on first subscription, listens to wallet changes in `chrome.storage.session`
- `userCertificationsService` — fetched via hook `useEffect` on wallet change

### Hook Patterns (55 hooks)

Hooks are **thin orchestration wrappers** — they delegate all business logic to services:

| Pattern | Usage | Example |
|---|---|---|
| **useSyncExternalStore** | Shared singleton state | `useDiscoveryScore` (41 lines), `useUserCertifications` (78 lines) |
| **Thin facade** | Returns service methods bound to wallet | `useCreateAtom` (26 lines) |
| **useState + useCallback** | Local UI state + service delegation | `useVoteOnTriple` (139 lines), `useInterestAnalysis` (194 lines) |
| **React Query** | Generated GraphQL hooks | `useTripleVotes`, various read hooks |

### Logger Pattern

```typescript
// In hooks:
import { createHookLogger } from "~/lib/utils"
const logger = createHookLogger("MyHookName")

// In services:
import { createServiceLogger } from "~/lib/utils"
const logger = createServiceLogger("MyServiceName")
```

### Pure Utility Functions

Stateless calculation functions — never duplicate in components or hooks:

```typescript
// Domain utilities (domainUtils.ts)
import { extractDomain, normalizeDomain, shouldExcludeDomain } from "~/lib/utils"

// Level system (levelCalculation.ts)
import { calculateLevel, calculateLevelProgress, LEVEL_THRESHOLDS } from "~/lib/utils"

// Formatters (formatters.ts)
import { getFaviconUrl, formatDuration, formatShortDate, formatBalance } from "~/lib/utils"

// Certification helpers (certificationHelpers.ts)
import { intentionToCertification, trustToCertification, getEffectiveCertStatus,
         calculateDominantCertification, sumCertifications } from "~/lib/utils"

// Discovery calculations (discoveryUtils.ts)
import { buildPagePositionMap, calculateDiscoveryRanking, calculateDiscoveryGold,
         buildDiscoveryStats } from "~/lib/utils"

// Streak calculations (streakUtils.ts)
import { calculateStreaks, toDateStr } from "~/lib/utils"
```

### Predicate Constants (Single Source of Truth)

All predicate IDs, labels, and mappings are centralized in `lib/config/predicateConstants.ts`. **Never** duplicate these in hooks or components:

```typescript
import {
  INTENTION_PREDICATE_IDS, ALL_PREDICATE_IDS,
  CERTIFICATION_PREDICATE_LABELS, WEB_ACTIVITY_PREDICATES,
  PREDICATE_LABEL_TO_INTENTION, PREDICATE_ID_TO_CERTIFICATION
} from "~/lib/config/predicateConstants"
```

Key exports:
- **ID groups:** `INTENTION_PREDICATE_IDS`, `OAUTH_PREDICATE_IDS`, `TRUST_PREDICATE_IDS`, `ALL_PREDICATE_IDS`
- **Label groups:** `INTENTION_PREDICATE_LABELS`, `INTENTION_PREDICATE_LABELS_WITH_LEGACY` (trailing-space variant), `ALL_PREDICATE_LABELS`, `CERTIFICATION_PREDICATE_LABELS`, `WEB_ACTIVITY_PREDICATES`
- **Mappings:** `PREDICATE_LABEL_TO_INTENTION`, `PREDICATE_LABEL_TO_TRUST`, `PREDICATE_ID_TO_CERTIFICATION`, `PREDICATE_ID_TO_INTENTION`, `PREDICATE_ID_TO_LABEL`

## How-To Recipes

### Add a new predicate (e.g. "visits for gaming")

1. **`chainConfig.dev.ts`** + **`chainConfig.prod.ts`** — Add the ID in `PREDICATE_IDS` and label in `PREDICATE_NAMES`
2. **`predicateConstants.ts`** — Add to the relevant groups (`INTENTION_PREDICATE_IDS`, `INTENTION_PREDICATE_LABELS`, mappings)
3. **`types/discovery.ts`** — Add `'for_gaming'` to `IntentionPurpose` union type
4. Done — all hooks/services pick it up automatically from the constants.

### Add a new singleton service

```typescript
// 1. Create lib/services/MyService.ts
import { createServiceLogger } from "../utils/logger"
const logger = createServiceLogger("MyService")

class MyServiceClass {
  myMethod() { ... }
}
export const myService = new MyServiceClass()
export { MyServiceClass }

// 2. Add to lib/services/index.ts barrel
export { MyServiceClass, myService } from './MyService'

// 3. Import from barrel everywhere
import { myService } from "~/lib/services"
```

### Add a hook that delegates to a service

```typescript
// hooks/useMyFeature.ts — keep it THIN
import { useSyncExternalStore } from "react"
import { myService } from "~/lib/services"

export const useMyFeature = () => {
  // Option A: useSyncExternalStore (if service has shared state)
  const state = useSyncExternalStore(myService.subscribe, myService.getSnapshot)
  return { ...state, refetch: () => myService.refetch() }

  // Option B: thin facade (if service is stateless)
  const { walletAddress } = useWalletFromStorage()
  return { doThing: (data) => myService.doThing(data, walletAddress) }
}
```

### Add a new GraphQL query

1. Create/edit `.graphql` file in `extension/packages/graphql/src/queries/`
2. Run `cd extension/packages/graphql && pnpm codegen`
3. Import the generated Document + types from `@0xsofia/graphql`:
   ```typescript
   import { MyNewQueryDocument, type MyNewQueryQuery } from "@0xsofia/graphql"
   ```
4. Use with `intuitionGraphqlClient.fetchAllPages(MyNewQueryDocument, vars, 'fieldName', limit, maxPages)`

### Add a new utility function

1. Add the function to the appropriate file in `lib/utils/` (or create a new file if no fit)
2. Export from `lib/utils/index.ts` barrel
3. Import from `"~/lib/utils"` everywhere

## Key Flows (End-to-End)

### URL Certification Flow

```
User clicks "Certify for Work" on a URL in GroupDetailView
    ↓
useCreateTripleOnChain hook
    ↓ resolves predicate ID (existing or creates atom)
    ↓ resolves object ID (pin URL to IPFS → create atom)
    ↓
tripleService.createTripleOnChain(subjectId="I", predicateId, objectId, address)
    ↓ checks if triple exists on-chain (BlockchainService.checkTripleExists)
    ↓
    ├─ Triple exists → DEPOSIT (curveId=2n progressive, min 0.01 TRUST)
    │   ↓ simulate SofiaFeeProxy.deposit → execute → wait receipt
    │
    └─ Triple doesn't exist → CREATE (curveId=1n linear)
        ↓ simulate SofiaFeeProxy.createTriples → execute → wait receipt
    ↓
groupManager.certifyUrl(domain, url, "work") → IndexedDB update + 10 Gold
questTrackingService.recordCertificationActivity() → streak tracking
```

### Vote Flow (Like/Dislike)

```
User clicks Like on a certification in CircleFeedTab
    ↓
useVoteOnTriple.vote(tripleTermId, "like")
    ↓ ensureProxyApproval() (one-time)
    ↓ resolve "like" predicate ID (tripleService.getPredicateIdIfExists)
    ↓
tripleService.createTripleOnChain(
  subject = SUBJECT_IDS.I,
  predicate = likePredicateId,
  object = tripleTermId,          ← nested: object IS another triple
  address, VOTE_STAKE=1 TRUST, curveId=1n
)
    ↓
questTrackingService.recordVoteActivity()
goldService.addVoteGold(address, dailyCount)  ← 5 Gold/vote, cap 10/day
```

### Interest Analysis Flow

```
User opens Interest tab → useInterestAnalysis.analyzeInterests(accountId)
    ↓
interestAnalysisService.loadCachedInterest(accountId) → localStorage
    ↓ (show cached data immediately)
mcpService.fetchAccountActivity(accountId)
    ↓ MCP session init → tools/call "get_account_activity"
    ↓ returns domain groups with predicate counts
interestAnalysisService.analyzeWithAgent(activityData)
    ↓ calls Mastra skillsAnalysisAgent → AI categorization
    ↓ maps predicates → CertificationBreakdown per interest
interestAnalysisService.mergeInterests(cached, new)
    ↓ fuzzy name matching, max certifications, recalculate XP/level
interestAnalysisService.saveCachedInterest() → localStorage
```

### Discovery Score Flow

```
discoveryScoreService auto-initializes on first useSyncExternalStore subscription
    ↓ reads wallet from chrome.storage.session
    ↓ listens to chrome.storage.onChanged for wallet changes
    ↓
fetchDiscoveryScore(walletAddress)
    ↓ Promise.all([userTriples, allTriples]) via paginated GraphQL
    ↓
buildPagePositionMap(allTriples) → Map<objectTermId, positions[]>
calculateDiscoveryRanking(userTriples, map, userAddress)
    ↓ for each user triple:
    ↓   rank = position in pagePositionMap (by created_at)
    ↓   rank 1 → Pioneer (+50 Gold)
    ↓   rank 2-10 → Explorer (+20 Gold)
    ↓   rank 11+ → Contributor (+10 Gold)
    ↓
goldService.setDiscoveryGold(wallet, total)
    ↓ syncs to chrome.storage.local
```

## Gotchas and Known Quirks

### Legacy trailing space in predicate labels
The on-chain data contains `"visits for learning "` (with a trailing space) from old certifications. This is why `INTENTION_PREDICATE_LABELS_WITH_LEGACY` exists and why `PREDICATE_LABEL_TO_INTENTION` has two entries for learning. **Always use the `_WITH_LEGACY` variant** when querying on-chain data.

### Bonding curve IDs
- `curveId = 1n` → **Linear** (used for atom/triple creation AND vote deposits)
- `curveId = 2n` → **Progressive** (used for regular triple deposits)
- Vote deposits intentionally use `1n` (not `2n`) — this is NOT a bug.

### Old atoms vs new atoms (URL resolution)
- **New atoms:** title in `atom.label`, URL in `atom.value.thing.url`
- **Old atoms:** URL in `atom.label` directly (no `value.thing.url`)
- `UserCertificationsService.fetchCertifications()` handles both via priority: `value.thing.url` → fallback to `label`

### GraphQL address case sensitivity
The Intuition indexer stores account addresses in **EIP-55 checksummed format** (mixed case, e.g. `0xc634457aD68b037E2D5aA1C10c3930d7e4E2d551`).
- Use `_ilike` (case-insensitive) for `account_id` filters — NOT `_eq`
- The `FindTriples` query uses `_eq` for positions — do NOT modify it (used elsewhere)
- The `FindNestedTriples` query uses `_ilike` for positions — use this for vote queries

### atoms type has no `id` field
The GraphQL `atoms` type does NOT have an `id` field — use `term_id` instead. Codegen will fail if you try `id`.

### Vault positions
`account_id` in vault positions = user's full wallet address (matches `atom.value.account.id`, both lowercased for comparison).

### React Query v5 — `isLoading` vs `isFetching`
Generated hooks (`@0xsofia/graphql`) use `@tanstack/react-query` v5:
- `isLoading` = `isPending && isFetching` — only `true` on first load (no cached data)
- `isFetching` = `true` whenever a request is in flight (including refetches)
- For refresh/reload buttons, use `isFetching` to show loading state, not `isLoading`

### Two different level systems
- `calculateLevel(certifiedCount)` → Echoes groups (on-chain certifications). Thresholds: `[0, 3, 7, 12, 18, 25, 33, 42, 52, 63, 75]`
- `calculateLevelFromXP(xp)` → Quest system (badge XP). **Different** thresholds.
- Do NOT confuse them.

### MV3 service worker death
The service worker can be killed after ~30s of inactivity:
- No in-memory state that can't be lost — flush to IndexedDB immediately
- Use `chrome.storage.session` for state that must survive restarts
- Use `chrome.alarms` instead of `setTimeout` for timers
- `SessionTracker` flushes every URL immediately (threshold=1)

## Chrome Message Passing

Content scripts communicate with the service worker via typed messages (58 types defined in `extension/types/messages.ts`):

```
Content Script → chrome.runtime.sendMessage({ type: "TRACK_URL", data })
    → background/messageHandlers.ts routes to service
    → Response
```

Key flows:
- URL tracking: `tracking.ts` → `TRACK_URL` → `sessionTracker` → `groupManager` → IndexedDB
- Page analysis: `pageAnalyzer.ts` → `PAGE_DATA` → `pageDataService`
- Wallet bridge: `walletBridge.ts` ↔ `walletRelay.ts` ↔ background
- AI agents: hooks → `SEND_CHATBOT_MESSAGE` → `agentRouter` → Mastra HTTP API

## IndexedDB (10 stores)

Database: `sofia-extension-db` (version 8), managed by `SofiaIndexedDB` singleton in `lib/database/indexedDB.ts`. 9 data service classes in `lib/database/indexedDB-methods.ts`.

| Store | Service | Purpose |
|---|---|---|
| `TRIPLETS_DATA` | `tripletsDataService` | Sofia messages, triplet states, published details |
| `NAVIGATION_DATA` | `navigationDataService` | URL visit history and metadata |
| `USER_PROFILE` | `userProfileService` | Profile photo, bio, profile URL (singleton record) |
| `USER_SETTINGS` | `userSettingsService` | Theme, language, notifications (singleton record) |
| `SEARCH_HISTORY` | `searchHistoryService` | Search queries and results |
| `BOOKMARK_LISTS` | `bookmarkService` | Bookmark collection lists |
| `BOOKMARKED_TRIPLETS` | `bookmarkService` | Individual bookmarked triplets |
| `RECOMMENDATIONS` | `recommendationsService` | AI recommendations by wallet |
| `INTENTION_GROUPS` | `intentionGroupsService` | Intent-based URL grouping by domain |
| `USER_XP` | `userXPService` | Quest XP tracking |

### Content Scripts

| Script | Purpose |
|---|---|
| `tracking.ts` | Track page visits (3s delay, SPA detection) |
| `pageAnalyzer.ts` | Extract page metadata (title, description, OG tags) |
| `pulseCollector.ts` | Collect attention metrics |
| `walletBridge.ts` | EIP-6963 wallet provider detection |
| `walletRelay.ts` | Relay wallet messages to background |

## Dual Currency System (Gold + XP)

Two separate currencies — do NOT confuse:

| Currency | Service | Source | Purpose |
|---|---|---|---|
| **Gold** (private) | `goldService` | Discovery certifications (50/20/10), URL certifications (10), votes (5/day cap 10) | Spent on group level-ups |
| **XP** (public) | `xpService` | Quest badge claims only (derived, read-only) | Display only, never spent |

Gold constants: `GOLD_PER_CERTIFICATION = 10`, `LEVEL_UP_COSTS = [30, 40, 50, 60, 70, 80, 90, 100]`

## Echoes System (Groups/Levels)

Full documentation: `extension/ECHOES_SYSTEM.md`

### Unified Level Logic (BentoCard = DetailView)

Both `GroupBentoCard` and `GroupDetailView` MUST use identical logic:

| Logic | Implementation |
|-------|---------------|
| `certifiedCount` | `Math.max(p2Count, p1Count, group.certifiedCount)` — MAX of Pipeline 2, Pipeline 1, stored |
| `displayLevel` | `calculateLevel(certifiedCount)` — on-chain level |
| `progressPercent` / `xpToNextLevel` | `calculateLevelProgress(certifiedCount, displayLevel)` — progress from on-chain level |
| `canLevelUp` | `displayLevel > 1 && displayLevel > highestPredicateLevel` — predicate history check |

## Sofia-Mastra (AI Backend)

### Agents (in `sofia-mastra/src/agents/`)

| Agent | Purpose |
|---|---|
| `sofia` | Main conversational agent |
| `chatbot` | Chat interactions |
| `themeExtractor` | Extract themes from visited URLs |
| `pulseAgent` | Analyze browsing sessions |
| `recommendationAgent` | Generate personalized recommendations |
| `intentionCertifier` | Certify browsing intentions on-chain |
| `skillsAnalysisAgent` | Categorize domain activity into interests |

### Workflows (in `sofia-mastra/src/workflows/`)

- `certifyIntention` — Certify a URL as an intention on the blockchain
- `themeExtraction` — Extract themes from browsing history
- `pulseAnalysis` — Analyze a browsing session
- `recommendation` — Generate recommendations from user data

### LLM Provider

GaiaNet with `Qwen2.5-14B-Instruct-Q5_K_M` model. Configured via `@ai-sdk/openai-compatible`. Env vars in `sofia-mastra/.env`.

### MCP Connection

The Mastra backend connects to `intuition-mcp-server` for knowledge graph access. The extension also connects directly via `MCPService` for interest analysis.

## Intuition-MCP-Server

MCP server exposing the Intuition knowledge graph. Supports both HTTP (`PORT=3001 SERVER_MODE=http`) and stdio modes.

## Code Conventions

### Formatting (Prettier)

Configured in `extension/.prettierrc.mjs`:
- No semicolons (`semi: false`)
- Double quotes (`singleQuote: false`)
- No trailing commas (`trailingComma: "none"`)
- `printWidth: 80`, `tabWidth: 2`
- Import order (via `@ianvs/prettier-plugin-sort-imports`):
  1. Node.js built-in modules
  2. Third-party modules
  3. `@plasmo/*`
  4. `@plasmohq/*`
  5. `~*` (internal alias imports)
  6. Relative imports (`./`, `../`)

### TypeScript

- `strict: false` in tsconfig (loose mode)
- Target: ES2020, Module: ES2020
- Types centralized in `extension/types/` (22 files)
- React Query (`@tanstack/react-query`) for async state management
- Viem + Wagmi for blockchain interaction
- Apollo Client for GraphQL

### Component Patterns

- UI in `extension/components/` — pages, modals, ui, charts, layout
- Routing via custom `RouterProvider` (not react-router for side panel navigation)
- Tailwind 4 for styling
- Framer Motion for animations
- Three.js + OGL for 3D effects

## Environment Variables

### Extension (`extension/.env.development` / `.env.production`)

| Variable | Purpose | Default |
|---|---|---|
| `PLASMO_PUBLIC_SOFIA_SERVER_URL` | Sofia backend URL | `http://localhost:3000` |
| `PLASMO_PUBLIC_MASTRA_URL` | Mastra agent API URL | `http://localhost:4111` |
| `PLASMO_PUBLIC_MCP_URL` | MCP server URL (for MCPService) | `http://localhost:3001` |
| `PLASMO_PUBLIC_NETWORK` | Chain: `local` / `testnet` / `mainnet` | `testnet` |
| `PLASMO_PUBLIC_PRIVY_APP_ID` | Privy auth app ID | — |
| `PLASMO_PUBLIC_PRIVY_CLIENT_ID` | Privy auth client ID | — |

### Sofia-Mastra (`sofia-mastra/.env`)

| Variable | Purpose |
|---|---|
| `GAIANET_NODE_URL` | GaiaNet node endpoint |
| `GAIANET_API_KEY` | GaiaNet API key |
| `GAIANET_MODEL` | LLM model name |
| `GAIANET_EMBEDDING_MODEL` | Embedding model name |
| `GAIANET_EMBEDDING_URL` | Embedding endpoint |

## Blockchain Networks

| Parameter | Testnet (`pnpm dev`) | Mainnet (`pnpm build`) |
|-----------|---------------------|----------------------|
| Chain ID | 13579 | 1155 |
| RPC | testnet.rpc.intuition.systems | rpc.intuition.systems |
| Explorer | testnet.explorer.intuition.systems | explorer.intuition.systems |
| GraphQL | testnet.intuition.sh/v1/graphql | mainnet.intuition.sh/v1/graphql |
| Sofia Fee Proxy | `0x26F81d723Ad1648194FAA4b7E235105Fd1212c6c` | — |
| MultiVault | `0x6E35cF57A41fA15eA0EaE9C33e751b01A784Fe7e` | — |

All transactions go through the Sofia Fee Proxy → MultiVault. Config in `lib/config/chainConfig.dev.ts` / `chainConfig.prod.ts`.

## Key Files Reference

| File | What it contains |
|---|---|
| `extension/ARCHITECTURE.md` | Detailed architecture documentation |
| `extension/ECHOES_SYSTEM.md` | Full Echoes (Groups/Levels) system documentation |
| `extension/background/oauth/README.md` | OAuth subsystem docs (5 platforms) |
| `extension/packages/graphql/README.md` | GraphQL API documentation |
| `extension/types/messages.ts` | 58 Chrome message type definitions |
| `extension/background/constants.ts` | URL filtering, security patterns |
| `extension/lib/config/chainConfig.ts` | Chain/network config selector (dev/prod/local) |
| `extension/lib/config/predicateConstants.ts` | **Single source of truth** for all predicate IDs, labels, mappings |
| `extension/background/messageHandlers.ts` | Message routing (content script → services) |
| `extension/lib/database/indexedDB.ts` | SofiaIndexedDB class (10 stores) |
| `extension/lib/database/indexedDB-methods.ts` | 9 typed data service classes |
| `extension/lib/utils/discoveryUtils.ts` | Pure calculation functions for discovery ranking |
| `extension/lib/utils/streakUtils.ts` | Pure calculation functions for streak leaderboard |
| `extension/lib/utils/domainUtils.ts` | Domain extraction, normalization, exclusion |

## Security Patterns

- 200+ blocked URL patterns (auth, ads, tracking, sensitive pages)
- Sensitive param stripping (token, password, api_key)
- Restricted protocols: chrome://, file://, extension pages
- Restricted domains: extension stores, ad networks
- Wallet provider isolation via content script bridge
- External message origin validation (`ALLOWED_EXTERNAL_ORIGINS`)
- All patterns in `extension/background/constants.ts`

---

## Detailed Code Patterns

### Service Instantiation Patterns

Three patterns exist — use the right one:

```typescript
// Pattern A: Class + singleton export (most common — 15 services)
class GoldServiceClass {
  async getGoldState(wallet: string): Promise<GoldState> { ... }
}
export const goldService = new GoldServiceClass()
export { GoldServiceClass }

// Pattern B: getInstance() singleton (immutable — 4 services)
class PageDataServiceClass {
  private static instance: PageDataServiceClass
  static getInstance(): PageDataServiceClass {
    if (!PageDataServiceClass.instance) PageDataServiceClass.instance = new PageDataServiceClass()
    return PageDataServiceClass.instance
  }
  private constructor() {}
}
export const pageDataService = PageDataServiceClass.getInstance()

// Pattern C: Static methods only (stateless — BlockchainService, QuestBadgeService)
export class BlockchainService {
  static async calculateDepositFee(...) { }
  static async checkAtomExists(...) { }
  // No instance, all static
}
```

### useSyncExternalStore Protocol (Reactive Singleton State)

For services that expose shared state to React:

```typescript
class MyReactiveServiceClass {
  private state: MyState = { /* initial */ }
  private listeners = new Set<() => void>()
  private initialized = false

  // PUBLIC: React API
  getSnapshot = (): MyState => this.state
  subscribe = (listener: () => void): (() => void) => {
    this.listeners.add(listener)
    if (!this.initialized) this.initializeStore()  // Lazy init
    return () => this.listeners.delete(listener)
  }

  // PRIVATE: Update + notify
  private updateState(partial: Partial<MyState>) {
    this.state = { ...this.state, ...partial }
    for (const listener of this.listeners) listener()
  }

  // PRIVATE: Lazy init (auto-subscribe to wallet changes)
  private initializeStore() {
    if (this.initialized) return
    this.initialized = true
    chrome.storage.session.get(["walletAddress"]).then(result => {
      this.handleWalletChange(result.walletAddress || null)
    })
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "session" && changes.walletAddress) {
        this.handleWalletChange(changes.walletAddress.newValue || null)
      }
    })
  }
}
```

**Key**: Arrow function fields for `getSnapshot`/`subscribe` to preserve `this` context.

### In-Flight Guard (Prevent Duplicate Fetches)

```typescript
private fetchInFlight = false

private async fetchData(wallet: string) {
  if (this.fetchInFlight) return  // Skip if already fetching
  this.fetchInFlight = true
  try {
    // ... fetch logic ...
  } finally {
    this.fetchInFlight = false
  }
}
```

Used by: `DiscoveryScoreService`, `UserCertificationsService`, hooks with `useRef(false)`.

### Wallet Address Handling Rules

```typescript
// Storage keys: ALWAYS lowercase
const key = getWalletKey("discovery_gold", walletAddress.toLowerCase())

// On-chain operations: ALWAYS checksummed (viem)
import { getAddress } from "viem"
const checksumAddress = getAddress(walletAddress)

// Comparisons: ALWAYS lowercase both sides
if (walletA?.toLowerCase() === walletB?.toLowerCase()) { ... }

// GraphQL queries: use _ilike (case-insensitive)
{ account_id: { _ilike: $address } }
```

### Chrome Storage Isolation Pattern

All per-user data is prefixed with wallet address:

```typescript
import { getWalletKey } from "~/lib/utils"

const discoveryKey = getWalletKey("discovery_gold", walletAddress.toLowerCase())
// → "discovery_gold_0xabc..."

await chrome.storage.local.set({ [discoveryKey]: value })
const result = await chrome.storage.local.get([discoveryKey])
```

**Three storage areas used:**
| Area | Persistence | Usage |
|------|-------------|-------|
| `chrome.storage.session` | Until browser restart | `walletAddress`, `walletType` |
| `chrome.storage.local` | Permanent | Gold, XP, quest progress, OAuth tokens, proxy approvals |
| `IndexedDB` | Permanent | Groups, triplets, navigation, bookmarks (10 stores) |

### Caching Patterns

**1. In-memory Map cache** (IPFS, ENS, GraphQL):
```typescript
const cache = new Map<string, Data | null>()

async function fetchWithCache(key: string): Promise<Data | null> {
  if (cache.has(key)) return cache.get(key)!
  const data = await fetchData(key)
  cache.set(key, data)  // Also caches null (prevents retry on failure)
  return data
}

export function clearCache() { cache.clear() }
```

**2. Chrome storage with TTL**:
```typescript
const CACHE_DURATION = 120_000  // 2 min
const cacheKey = getWalletKey("progress_cache", wallet)
const timestampKey = getWalletKey("progress_timestamp", wallet)

const result = await chrome.storage.local.get([cacheKey, timestampKey])
if (result[cacheKey] && Date.now() - (result[timestampKey] || 0) < CACHE_DURATION) {
  return result[cacheKey]  // Use cached
}
```

**3. localStorage** (Interest analysis):
```typescript
localStorage.setItem(cacheKey, JSON.stringify(data))
const cached = JSON.parse(localStorage.getItem(cacheKey) || "null")
```

### Error Handling Conventions

**Services/Utils**: Return `null` or fallback, never throw (except blockchain ops):
```typescript
// ✓ Return null on failure
export function extractDomain(label: string): string | null {
  try { /* ... */ } catch { return null }
}

// ✓ Return result object with success flag
async spendGold(wallet: string, amount: number): Promise<{ success: boolean; error?: string }> {
  if (state.totalGold < amount) return { success: false, error: "Not enough Gold" }
  // ...
  return { success: true }
}
```

**Hooks**: Catch errors and set error state:
```typescript
const [error, setError] = useState<string | null>(null)
try {
  await someService.doThing()
} catch (err) {
  setError(err instanceof Error ? err.message : "Unknown error")
}
```

### Batch Processing Pattern

For IPFS, ENS, or any network-bound operations:

```typescript
async function batchProcess<T>(items: string[], concurrency = 5): Promise<Map<string, T>> {
  const results = new Map<string, T>()
  for (let i = 0; i < items.length; i += concurrency) {
    const batch = items.slice(i, i + concurrency)
    await Promise.all(batch.map(async item => {
      const data = await fetchSingle(item)
      if (data) results.set(item, data)
    }))
  }
  return results
}
```

Used by: `batchFetchIPFS(uris, 5)`, `batchGetEnsAvatars(accounts)`.

---

## Component Writing Guide

### Component Structure Template

```typescript
// 1. React imports
import { useState, useCallback, useMemo } from "react"

// 2. Third-party
import { formatUnits } from "viem"

// 3. Internal hooks (barrel only)
import { useGoldSystem, useWalletFromStorage } from "~/hooks"

// 4. Internal utils (barrel only)
import { calculateLevel, getFaviconUrl } from "~/lib/utils"

// 5. Relative imports (components, styles)
import WeightModal from "../modals/WeightModal"
import "../styles/MyComponent.css"

// 6. Props interface
interface MyComponentProps {
  data: SomeType
  onAction: (id: string) => void
  isLoading?: boolean
}

// 7. Component function
const MyComponent = ({ data, onAction, isLoading = false }: MyComponentProps) => {
  // Hooks
  const { walletAddress } = useWalletFromStorage()

  // State
  const [selected, setSelected] = useState<string | null>(null)

  // Computed (memoized if expensive)
  const level = useMemo(() => calculateLevel(data.certCount), [data.certCount])

  // Callbacks
  const handleClick = useCallback((id: string) => {
    setSelected(id)
    onAction(id)
  }, [onAction])

  // Render
  if (isLoading) return <div className="loading-state">Loading...</div>
  if (!data) return <div className="empty-state">No data</div>

  return (
    <div className="my-component">
      {/* content */}
    </div>
  )
}

export default MyComponent
```

### Component Rules

1. **Never call services directly** — always go through hooks
2. **Import from barrel files only** — `~/hooks`, `~/lib/utils`, `~/lib/services`
3. **Define explicit Props interface** — no inline types
4. **Handle 3 states**: loading, empty, content
5. **Callbacks prefix**: `on<Action>` for props, `handle<Action>` for internal
6. **Portal for modals**: Always `createPortal(<Modal />, document.body)`
7. **Prop defaults** in destructuring: `{ size = "medium" }: Props`
8. **Use `useMemo`** for expensive computations from props/state
9. **Track processing with Set<string>** for multi-item async operations

### Styling Patterns

**Primary**: CSS modules (colocated in `components/styles/`)
**Dynamic values**: CSS variables via inline style

```typescript
// CSS variables for dynamic theming
<div style={{ "--accent-color": color, "--level-color": levelColor } as React.CSSProperties}>
  <div className="my-component" /> {/* Uses var(--accent-color) in CSS */}
</div>
```

**CSS class conventions** (BEM-inspired):
```css
.group-bento-card { }            /* Block */
.group-bento-header { }          /* Element */
.group-bento-card.can-level-up { } /* Modifier */
.group-bento-card:hover { }      /* State */
```

**Conditional classes**:
```typescript
className={`filter-btn ${filter === "all" ? "active" : ""}`}
```

### Modal Pattern

All modals follow this structure:

```typescript
interface MyModalProps {
  isOpen: boolean
  onClose: () => void
  onSubmit: () => Promise<void>
  isProcessing: boolean
  transactionSuccess?: boolean
  transactionError?: string
}

const MyModal = ({ isOpen, onClose, ... }: MyModalProps) => {
  if (!isOpen) return null

  return createPortal(
    <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal-content">
        {/* State machine: Form → Processing → Success/Error */}
        {!transactionSuccess && !transactionError && <div>Form</div>}
        {isProcessing && <SofiaLoader />}
        {transactionSuccess && <div>Success</div>}
        {transactionError && <div>Error: {parseErrorMessage(transactionError)}</div>}
      </div>
    </div>,
    document.body
  )
}
```

### Navigation (Custom RouterProvider)

```typescript
// Available pages
type Page = "home" | "settings" | "profile" | "home-connected" | "Sofia"
  | "recommendations" | "resonance" | "chat" | "user-profile" | ...

// Navigate with data
const { navigateTo, goBack, currentPage } = useRouter()
navigateTo("user-profile", { termId: "...", label: "...", walletAddress: "..." })

// Deep link via chrome.storage.session
chrome.storage.session.set({ pending_profile_view: { termId, label } })
```

---

## Hook Writing Guide

### Hook File Structure Template

```typescript
import { useState, useCallback, useEffect, useMemo } from "react"
import { createHookLogger } from "~/lib/utils"
import { myService } from "~/lib/services"
import { useWalletFromStorage } from "./useWalletFromStorage"

const logger = createHookLogger("useMyFeature")

export interface UseMyFeatureResult {
  data: MyData | null
  loading: boolean
  error: string | null
  refetch: () => Promise<void>
  doAction: (id: string) => Promise<void>
}

export const useMyFeature = (param?: string): UseMyFeatureResult => {
  const { walletAddress } = useWalletFromStorage()
  const [data, setData] = useState<MyData | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const refetch = useCallback(async () => {
    if (!walletAddress) return
    setLoading(true)
    setError(null)
    try {
      const result = await myService.fetchData(walletAddress)
      setData(result)
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Unknown error"
      logger.error("Fetch failed", err)
      setError(msg)
    } finally {
      setLoading(false)
    }
  }, [walletAddress])

  useEffect(() => { refetch() }, [refetch])

  const doAction = useCallback(async (id: string) => {
    if (!walletAddress) { setError("Wallet not connected"); return }
    await myService.doAction(id, walletAddress)
    await refetch()
  }, [walletAddress, refetch])

  return { data, loading, error, refetch, doAction }
}
```

### Race Condition Prevention (useRef)

```typescript
const isFetchingRef = useRef(false)

const fetchData = useCallback(async () => {
  if (isFetchingRef.current) {
    logger.debug("Skipping fetch — already in progress")
    return
  }
  isFetchingRef.current = true
  try { /* ... */ }
  finally { isFetchingRef.current = false }
}, [])
```

### Read-Only Mode (Viewing Other Users)

```typescript
export const useMyFeature = (targetWalletAddress?: string) => {
  const { walletAddress: viewerWallet } = useWalletFromStorage()
  const walletAddress = targetWalletAddress || viewerWallet
  const isReadOnlyMode = !!targetWalletAddress

  // Skip write operations in read-only mode
  const doAction = useCallback(async () => {
    if (isReadOnlyMode) return { success: false, error: "Read-only mode" }
    // ...
  }, [isReadOnlyMode])
}
```

### Chrome Runtime Message Pattern (from hooks)

```typescript
// Send message to background service worker
const response = await chrome.runtime.sendMessage({
  type: "GET_INTENTION_GROUPS"
})
if (response.success) setGroups(response.groups)

// Listen for updates from background (with cleanup)
useEffect(() => {
  const handleMessage = (message: any) => {
    if (message.type === "GROUPS_UPDATED") loadGroups()
  }
  chrome.runtime.onMessage.addListener(handleMessage)
  return () => chrome.runtime.onMessage.removeListener(handleMessage)
}, [loadGroups])
```

---

## GraphQL Patterns

### Query Naming Conventions

| Pattern | Examples | Usage |
|---------|----------|-------|
| `Get<Entity>` | `GetAtoms`, `GetTriples` | Main paginated list |
| `Get<Entity>WithPositions` | `GetAtomsWithPositions` | List + user positions |
| `Get<Entity>Count` | `GetAtomsCount` | Count-only queries |
| `Find<Entity>` | `FindAtomIds`, `FindTriples` | Utility lookups |
| `Search<Domain>` | `GlobalSearch`, `SemanticSearch` | Search operations |

### Standard Paginated Query Template

```graphql
query GetTriples(
  $limit: Int
  $offset: Int
  $orderBy: [triples_order_by!]
  $where: triples_bool_exp
) {
  total: triples_aggregate(where: $where) {
    aggregate { count }
  }
  triples(limit: $limit, offset: $offset, order_by: $orderBy, where: $where) {
    ...TripleMetadata
  }
}
```

**Key**: Separate `_aggregate` for total count + main query for nodes. Offset-based pagination.

### Filtering Conventions

```graphql
# Address: ALWAYS _ilike (case-insensitive, EIP-55)
account_id: { _ilike: $address }

# Shares: String comparison (not numeric)
shares: { _gt: "0" }

# Predicates: IDs or labels with _in
predicate_id: { _in: $predicateIds }
predicate: { label: { _in: $labels } }

# Hostname: Pattern with _ilike
object: { label: { _ilike: $hostnameLike } }

# Multiple conditions: _and array
_and: [
  { predicate_id: { _eq: $predicateId } }
  { positions: { account_id: { _ilike: $address }, shares: { _gt: "0" } } }
]
```

### Fragment Organization (11 fragments)

| Fragment | Purpose |
|----------|---------|
| `AtomMetadata` | Basic atom + `AtomValue` (person/thing/org/account) |
| `AtomVaultDetails` | Vault info with positions |
| `TripleMetadata` | Subject/predicate/object atoms + vault |
| `TripleVaultDetails` | Term + counter_term vaults |
| `PositionDetails` | Full position with nested vault/atom/triple |
| `PositionFields` | Simplified position fields |
| `VaultDetails` | Basic vault details |
| `FollowMetadata` | Triple with vault positions for follows |

### Codegen Integration

```typescript
// After editing .graphql files:
// cd extension/packages/graphql && pnpm codegen

// Generated output: src/generated/index.ts
// - TypeScript types for all operations
// - React Query v5 hooks: useGetAtoms(), useGetTriplesInfinite()
// - DocumentNodes: GetAtomsDocument, GetTriplesDocument
// - Query keys for cache invalidation

// Extract result types from generated query types:
type UserTripleResult = UserIntentionTriplesQuery["triples"][number]

// Use with paginated fetcher:
const results = await intuitionGraphqlClient.fetchAllPages<UserTripleResult>(
  UserIntentionTriplesDocument,
  { predicateLabels: CERTIFICATION_PREDICATE_LABELS, userAddress },
  "triples",  // result key
  100,         // page size
  100          // max pages
)
```

### GraphQL Anti-Patterns

- **Never hardcode** curve IDs, addresses, limits — use variables
- **Never fetch all nodes to count** — use `_aggregate`
- **Never filter client-side** — push to `where` clause
- **Never duplicate fragments** — reuse from `src/fragments/`
- **Never use `_ilike` for exact lookups** — use `_eq` for indexed fields
- Use backend database functions when available: `following()`, `positions_from_following()`, `search_positions_on_subject()`

---

## Background & Content Script Patterns

### Background Service Worker (index.ts)

```
chrome.runtime.onInstalled → checkExistingConnection()
    → init() → setupMessageHandlers() + initializeBadgeCount()
    → chrome.action.onClicked → open side panel
```

**Key rules:**
- Guard handlers with `if (handlersRegistered) return`
- Validate external message origins: `ALLOWED_EXTERNAL_ORIGINS`
- Delegate ALL business logic to services — background just routes
- Never keep persistent state in memory (MV3 service worker death)

### Message Handler Pattern

```typescript
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.type) {
    case "PAGE_DATA":
      pageDataService.handlePageData(message)
      break  // Fire-and-forget

    case "GET_INTENTION_GROUPS":
      groupManager.getAllGroups()
        .then(groups => sendResponse({ success: true, groups }))
        .catch(error => sendResponse({ success: false, error: error.message }))
      return true  // ← CRITICAL: return true for async sendResponse
  }
})
```

### Content Script Template (Plasmo)

```typescript
import type { PlasmoCSConfig } from "plasmo"

export const config: PlasmoCSConfig = {
  matches: ["<all_urls>"],
  all_frames: false,   // Avoid duplicate execution in iframes
  // world: "MAIN"     // Only for walletBridge.ts (EIP-6963)
}

// Filter sensitive URLs before sending
if (shouldIgnoreFrame()) return

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "MY_REQUEST") {
    sendResponse({ success: true, data: ... })
    return true  // Async response
  }
})
```

| Script | `all_frames` | `world` | Purpose |
|--------|-------------|---------|---------|
| `tracking.ts` | `true` | default | URL visit tracking (3s delay) |
| `pageAnalyzer.ts` | `false` | default | Extract page metadata |
| `walletBridge.ts` | `false` | `"MAIN"` | EIP-6963 wallet detection |
| `walletRelay.ts` | — | default | Relay wallet messages |
| `pulseCollector.ts` | `false` | default | Attention metrics |

### OAuth Architecture (5 platforms)

```
OAuthService
  ├── PlatformRegistry    → Config for 5 platforms
  ├── TokenManager        → Per-wallet token storage/refresh
  ├── OAuthFlowManager    → Authorization code / PKCE flows
  ├── PlatformDataFetcher → Platform API calls + incremental sync
  ├── TripletExtractor    → Platform data → triplets
  ├── SyncManager         → Track last sync time
  └── MessageHandler      → Handle OAuth messages
```

**Token storage**: `chrome.storage.local` with key `oauth_token_{platform}_{wallet_lowercase}`

---

## Agent Router (Mastra AI Backend)

### HTTP API Pattern

```typescript
const response = await fetch(`${MASTRA_API_URL}/api/agents/${agentName}/generate`, {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({
    messages: [{ role: "user", content: prompt }]
  })
})
const result = await response.json()
return JSON.parse(result.text)  // Agents return JSON as string
```

**Agents**: `CHATBOT`, `ThemeExtractor`, `PulseAgent`, `RecommendationAgent`

After extraction, triplets are stored in IndexedDB and UI is notified:
```typescript
await sofiaDB.put(STORES.TRIPLETS_DATA, parsedRecord)
chrome.runtime.sendMessage({ type: "ECHOES_UPDATED" }).catch(() => {})  // Fire-and-forget
```

---

## Type Definition Patterns

### Organization (per-domain, 22 files)

| File | Contains |
|------|----------|
| `messages.ts` | 58 Chrome message types (discriminated union) |
| `database.ts` | IndexedDB record types + `Omit` patterns for inserts |
| `discovery.ts` | `IntentionPurpose` union + companion config objects |
| `blockchain.ts` | Result types (success/error union), contract types |
| `wallet.ts` | Wallet connection state |
| `questTypes.ts` | `QUEST_DEFINITIONS` (174 items) + XP rewards |
| `intentionCategories.ts` | `INTENTION_CONFIG` with labels and colors |
| `viem.ts` | Branded types: `Address`, `Hash`, `Hex` (`0x${string}`) |
| `follows.ts` | View model pattern (`CommunityAccountVM`) |

### Conventions

- **Interfaces** for object shapes (records, props, API contracts)
- **Type aliases** for unions (`IntentionPurpose`, `MessageType`), branded types (`Address`)
- **`Props` suffix** for component props: `AvatarProps`, `WeightModalProps`
- **`Result` suffix** for hook returns: `VoteOnTripleResult`, `GoldSystemResult`
- **`Omit` pattern** for insert operations: `Omit<BookmarkList, "id">`
- **Companion config objects** for unions: `INTENTION_CONFIG: Record<IntentionType, { label, color }>`

---

## Utility Function Reference

| File | Key Functions | Purpose |
|------|---------------|---------|
| `logger.ts` | `createHookLogger`, `createServiceLogger` | Prefixed logging |
| `normalizeUrl.ts` | `normalizeUrl` | Strip tracking params |
| `cleanTitle.ts` | `cleanTitle`, `getDisplayTitle` | Remove site suffixes |
| `pageRestriction.ts` | `isRestrictedUrl` | Detect auth/ads/restricted pages |
| `ensUtils.ts` | `getEnsAvatar`, `batchGetEnsAvatars` | ENS resolver + cache |
| `avatar.ts` | `isValidImageUrl`, `generateDiceBearAvatar`, `getInitials` | Avatar fallback chain |
| `ipfsCache.ts` | `batchFetchIPFS`, `fetchIPFSMetadata`, `clearIPFSCache` | IPFS multi-gateway fetch |
| `questStatusHelpers.ts` | `calculateLevelFromXP`, `computeQuestStatuses` | Quest XP calculations |
| `levelCalculation.ts` | `calculateLevel`, `calculateLevelProgress` | Echoes group levels |
| `storageKeyUtils.ts` | `getWalletKey` | Per-wallet storage keys |
| `formatters.ts` | `getFaviconUrl`, `formatDuration`, `formatBalance` | Display formatters |
| `domainUtils.ts` | `normalizeDomain`, `extractDomain`, `shouldExcludeDomain` | Domain handling |
| `certificationHelpers.ts` | `intentionToCertification`, `getEffectiveCertStatus`, `calculateDominantCertification` | Cert mappings |
| `discoveryUtils.ts` | `buildPagePositionMap`, `calculateDiscoveryRanking`, `calculateDiscoveryGold` | Discovery ranking (pure) |
| `streakUtils.ts` | `calculateStreaks`, `toDateStr` | Streak computation (pure) |
| `refetchUtils.ts` | `refetchWithBackoff`, `debounce` | Exponential backoff, debounce |
| `parseSofiaMessage.ts` | `parseSofiaMessage` | JSON parser with 3-tier fallback |
| `circleInterestUtils.ts` | `fetchMemberDomainActivity` | GraphQL fetch + domain grouping |

### Utility Naming Conventions

| Prefix | Usage | Examples |
|--------|-------|----------|
| `get` | Retrieve/fetch | `getEnsAvatar()`, `getFaviconUrl()`, `getWalletKey()` |
| `calculate` | Pure computation | `calculateLevel()`, `calculateStreaks()` |
| `build` | Construct objects | `buildPagePositionMap()`, `buildDiscoveryStats()` |
| `extract` | Parse/extract | `extractDomain()`, `extractHostname()` |
| `normalize` | Standardize format | `normalizeDomain()`, `normalizeUrl()` |
| `is` / `should` | Boolean predicate | `isValidImageUrl()`, `shouldExcludeDomain()` |
| `format` | Display transform | `formatDuration()`, `formatBalance()` |
| `batch` | Multiple items | `batchFetchIPFS()`, `batchGetEnsAvatars()` |
| `clear` | Reset cache/state | `clearIPFSCache()`, `clearEnsAvatarCache()` |

---

## Workflow Rules

### Re-plan on Failure
If an approach goes sideways (unexpected errors, wrong assumptions, growing complexity), **STOP immediately** and re-plan. Do not keep pushing a broken approach hoping it will work.

### Lessons After Every Correction
After ANY correction from the user, update `MEMORY.md` with the pattern learned. Do not wait for multiple occurrences — one correction is enough to record a lesson.

### Staff Engineer Gate
Before marking a task as done, ask: **"Would a staff engineer approve this?"** Check for edge cases, verify the change doesn't introduce regressions, and diff behavior when relevant.

### Zero Context-Switch Bug Fixing
When given a bug report: just fix it. Point at logs, errors, root causes — then resolve them. The user should not need to provide hand-holding or step-by-step guidance. Zero context switching required from the user.

### Keep Usecase File Updated
When implementing a new user-facing feature or removing an existing one, update `.claude/Sofia - Usecase.md`. This file is the single source of truth for what a user can do in Sofia — used for marketing and tweet generation.

---

## Anti-Patterns to Avoid

### Architecture

- **Never call services from components** — always go through hooks
- **Never import from individual files** — always use barrel files
- **Never duplicate predicate IDs/labels** — single source in `predicateConstants.ts`
- **Never keep persistent state in service worker memory** — use chrome.storage or IndexedDB
- **Never use `chrome.alarms`** — (currently uses setTimeout, but should migrate)

### TypeScript

- **Never use `atoms.id`** in GraphQL — use `term_id` (codegen will fail)
- **Never compare addresses with `===`** — always `toLowerCase()` both sides
- **Never use `_eq` for address filtering** in GraphQL — use `_ilike`
- **Never confuse Gold with XP** — different currencies, different services, different level systems

### React

- **Never pass recreated objects in useEffect deps** — extract primitive values
- **Never skip error/loading/empty states** — always handle all three
- **Never forget `return true`** in async `chrome.runtime.onMessage` handlers
- **Never forget cleanup** in useEffect with listeners — always return unsubscribe function

### GraphQL

- **Never hardcode** curve IDs, addresses, or limits in queries — use variables
- **Never fetch all nodes to count** — use `_aggregate`
- **Never filter large datasets client-side** — push filters to `where` clause
- **Never forget `_WITH_LEGACY` labels** when querying on-chain predicate data

---

## Complete How-To Recipes

### Add a new component with hook

```bash
# 1. Create the hook (thin wrapper around service)
# hooks/useMyFeature.ts

# 2. Add to hooks/index.ts barrel
export { useMyFeature } from "./useMyFeature"
export type { UseMyFeatureResult } from "./useMyFeature"

# 3. Create the component
# components/pages/MyFeaturePage.tsx

# 4. Create CSS file
# components/styles/MyFeature.css

# 5. Add route in RouterProvider if needed
```

### Add a new Chrome message type

1. Add type to `extension/types/messages.ts` — `MessageType` union
2. Add handler in `extension/background/messageHandlers.ts` — `switch (message.type)`
3. Send from hook/component: `chrome.runtime.sendMessage({ type: "MY_TYPE", data })`

### Add a new IndexedDB store

1. Increment `DB_VERSION` in `lib/database/indexedDB.ts`
2. Add store name to `STORES` const
3. Add `createObjectStore` in `onupgradeneeded`
4. Create service class in `lib/database/indexedDB-methods.ts`
5. Export from `lib/database/index.ts` barrel

### Add a new OAuth platform

1. Add platform config in `background/oauth/platforms/`
2. Register in `PlatformRegistry`
3. Add data fetcher in `PlatformDataFetcher`
4. Add triplet extractor in `TripletExtractor`
5. Test with `chrome.identity.launchWebAuthFlow()`
