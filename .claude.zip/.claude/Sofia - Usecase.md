# Sofia — User Actions Reference

> Use this as a tweet inspiration bank. Each action = a potential tweet angle.

---

## Browsing & Tracking

En tant qu'utilisateur je peux:

- **Naviguer sur le web normalement** et Sofia track automatiquement mes pages visitees en arriere-plan
- **Voir mes sites organises par domaine** dans des "Echoes" — des groupes intelligents crees automatiquement
- **Activer/desactiver le tracking** a tout moment dans les Settings
- **Importer mes bookmarks Chrome** au premier lancement pour demarrer avec un historique riche

---

## Certifier mes intentions (on-chain)

En tant qu'utilisateur je peux:

- **Certifier une URL comme "visits for work"** — prouver on-chain que ce site fait partie de mon activite pro
- **Certifier une URL comme "visits for learning"** — attester que j'apprends sur ce site
- **Certifier une URL comme "visits for fun"** — marquer un site comme divertissement
- **Certifier une URL comme "visits for inspiration"** — taguer mes sources d'inspiration
- **Certifier une URL comme "visits for buying"** — tracer mes recherches d'achat
- **Certifier une URL comme "visits for music"** — identifier mes sources musicales
- **Certifier une URL comme "trusts" ou "distrust"** — exprimer ma confiance ou mefiance envers un site
- **Choisir le montant de TRUST a staker** sur chaque certification (Minimum 0.01 / Default 0.5 / Strong 1.0 / Custom)
- **Deposer du stake supplementaire** sur une certification existante pour renforcer mon signal

---

## Echoes — Groupes & Niveaux

En tant qu'utilisateur je peux:

- **Voir tous mes domaines visites** sous forme de cartes avec leur niveau, nombre d'URLs, et type dominant
- **Trier mes Echoes** par niveau, nombre d'URLs, ordre alphabetique, ou visite recente
- **Filtrer par type d'intention** (Work, Learning, Fun, Inspiration, Buying, Music, Trusted, Distrusted)
- **Ouvrir un domaine** pour voir toutes les URLs visitees et leur statut de certification
- **Level up un domaine** en depensant du Gold — l'IA genere un nouveau predicat unique pour ce groupe
- **Amplifier un domaine** — publier on-chain l'identite du groupe ("I [predicate] [domain]")
- **Supprimer un domaine** de ma vue locale (les certifications on-chain restent)
- **Retirer une URL** d'un groupe — si certifiee on-chain, je recupere mon stake

---

## Discovery & Recompenses

En tant qu'utilisateur je peux:

- **Etre recompense en Gold** selon mon rang de decouverte:
  - **Pioneer** (1er a certifier une page) → +50 Gold
  - **Explorer** (top 2-10) → +20 Gold
  - **Contributor** (11+) → +10 Gold
- **Gagner 10 Gold** par certification d'URL
- **Gagner 5 Gold par vote** (max 10 votes/jour)
- **Depenser mon Gold** pour level up mes groupes de domaines
- **Claim mon reward** directement apres une certification avec un badge Pioneer/Explorer/Contributor

---

## Pulse Analysis (AI)

En tant qu'utilisateur je peux:

- **Lancer une Pulse Analysis** — l'IA analyse tous mes onglets ouverts et en extrait des signaux (triplets)
- **Voir les signaux extraits** par session, avec mots-cles et patterns identifies
- **Selectionner les signaux pertinents** individuellement ou en masse
- **Amplifier mes signaux selectionnes** — les publier on-chain en un clic
- **Supprimer les signaux non pertinents** ou des sessions entieres

---

## Resonance — Social & Tendances

### Circle Feed
En tant qu'utilisateur je peux:

- **Voir le feed temps reel** des certifications de mon Trust Circle
- **Voter Like ou Dislike** sur les certifications des autres (on-chain, 1 TRUST par vote)
- **Filtrer le feed par type d'intention**
- **Visiter le profil** d'un membre de mon cercle
- **Voir les certifications par categorie** d'un autre utilisateur

### Trending
En tant qu'utilisateur je peux:

- **Decouvrir les pages les plus certifiees** du moment sur Intuition
- **Filtrer les tendances par type** d'intention
- **Ouvrir directement** une page tendance dans un nouvel onglet

### Streak & Leaderboard
En tant qu'utilisateur je peux:

- **Voir le classement des streaks** de certifications quotidiennes
- **Voir le classement des votes** quotidiens
- **Comparer ma position** avec les autres utilisateurs
- **Visiter le profil** de n'importe quel utilisateur du classement

---

## Profil & Identite

### Stats & Achievements
En tant qu'utilisateur je peux:

- **Voir mes stats de decouverte** — nombre de Pioneer/Explorer/Contributor, Gold total
- **Completer des quetes** (174 quetes disponibles) et claim du XP on-chain
- **Maintenir des streaks quotidiens** (Daily Voter, Daily Certification) et claim les rewards
- **Monter de niveau** via le systeme XP des quetes (systeme de badges)

### Interest Analysis (AI)
En tant qu'utilisateur je peux:

- **Lancer une analyse d'interets** — l'IA categorise mon activite on-chain en centres d'interet
- **Voir mes interets identifies** avec leur niveau et breakdown par type de certification
- **Partager mes interets sur X/Twitter** avec une image OG generee automatiquement

### Social Connections
En tant qu'utilisateur je peux:

- **Connecter 5 plateformes** via OAuth: X (Twitter), Discord, YouTube, Twitch, Spotify
- **Synchroniser mes donnees** de chaque plateforme (abonnements YouTube, guildes Discord, ecoutes Spotify, follows Twitch/Twitter)
- **Verifier mes socials on-chain** une fois les 5 connectes — attestation on-chain
- **Claim du XP** pour la quete "Social Linked" apres verification

---

## Communaute & Trust Circle

En tant qu'utilisateur je peux:

- **Suivre un compte** (Follow) — staker du TRUST pour etablir une connexion on-chain
- **Truster un compte** — ajouter quelqu'un a mon Trust Circle avec un stake supplementaire
- **Explorer les top comptes** sur Intuition via l'onglet Explore
- **Rechercher n'importe quel compte** Intuition par nom ou adresse
- **Voir mes followers, following, et trust circle** avec stats
- **Visiter le profil complet** de n'importe quel utilisateur (interests, achievements, community)

---

## Chat IA

En tant qu'utilisateur je peux:

- **Discuter avec Sofia** — un chatbot IA qui connait mon activite et peut m'aider
- **Poser des questions** sur mes habitudes de navigation, mes interets, ou demander des recommandations

---

## Bookmarks

En tant qu'utilisateur je peux:

- **Creer des listes de bookmarks** personnalisees avec nom et description
- **Ajouter mes signaux on-chain** (certifications) a une liste de bookmarks
- **Rechercher parmi mes signaux** pour les ajouter a une liste
- **Supprimer des listes** ou retirer des signaux individuels
- **Voir mes URLs certifiees** par categorie d'intention

---

## Settings & Donnees

En tant qu'utilisateur je peux:

- **Connecter/deconnecter mon wallet** via Privy
- **Supprimer toutes mes donnees locales** (reset complet: wallet, IndexedDB, OAuth tokens, Gold, XP, quetes)
- **Acceder au tutoriel** a tout moment depuis les Settings
- **Consulter la Privacy Policy et les Terms**

---

## Resume des actions blockchain

| Action | Cout |
|---|---|
| Certifier une URL | Min 0.01 TRUST |
| Amplifier un groupe | Min 0.01 TRUST |
| Level up un groupe | 30-100 Gold |
| Suivre un compte | Min 0.01 TRUST |
| Truster un compte | Min 0.01 TRUST |
| Voter Like/Dislike | 1 TRUST |
| Staker sur un triple | Custom |
| Claim XP (quete) | Gratuit (gas only) |
| Retirer une URL certifiee | Stake rendu |

---

## Tweet Angles par Feature

### Hook: "Sofia tracks your browsing and turns it into on-chain identity"
- Le tracking passif → certifications intentionnelles → identite verifiable

### Hook: "Your browsing history is worth something"
- Discovery rewards (Pioneer/Explorer/Contributor) → Gold → level up

### Hook: "AI meets blockchain"
- Pulse Analysis extrait des signaux → publies on-chain
- Interest Analysis categorise l'activite → profil d'interets partage

### Hook: "Social proof, but for your curiosity"
- Trust Circle → feed social → votes on-chain → leaderboard

### Hook: "Gamified knowledge graph"
- Quetes (174) → XP → badges → streaks → leaderboard

### Hook: "Own your attention data"
- 5 plateformes OAuth → donnees synchronisees → attestation on-chain
- Pas de data broker, l'utilisateur controle tout
